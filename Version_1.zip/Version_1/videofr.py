import PySimpleGUI as sg
import cv2
import face_recognition
from fr import Facerec
import time
from datetime import datetime

#encode faces from folder
sfr = Facerec()
sfr.load_encoding_images("images/")


def main():
    now = datetime.now()
    date_time = now.strftime("%m/%d/%Y, %H:%M:%S")
    sg.theme("LightGreen")

    # Define the window layout
    layout = [
        [sg.Text("OpenCV Demo", size=(60, 1), justification="center")],
        [sg.Image(filename="", key="-IMAGE-")],
        [sg.Button("Exit", size=(10, 1))],
    ]

    window = sg.Window("OpenCV Test", layout, location=(800, 400))

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

    cap = cv2.VideoCapture(0)

    while True:
        event, values = window.read(timeout=20)

        ret, frame = cap.read()

        # Convert into grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


        # Detect faces
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)

        face_locations, face_names = sfr.detect_known_faces(frame)
        # Draw rectangle around the faces
        for face_loc, name in zip(face_locations, face_names):
            # top=y1 left=x1 bottom=y2 right=x2
            y1, x1, y2, x2 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]

            cv2.putText(frame, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 0), 2)
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 200), 4)


            print(name + " " + date_time)
            #time.sleep(10)

        if event == "Exit" or event == sg.WIN_CLOSED:
            break


        imgbytes = cv2.imencode(".png", frame)[1].tobytes()
        window["-IMAGE-"].update(data=imgbytes)

    window.close()


main()