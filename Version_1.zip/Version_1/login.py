import PySimpleGUI as sg

from PIL import Image
import io, os
import cv2
from fr import Facerec
from datetime import datetime
#from database import database
import sys

import sqlite3
#conn = sqlite3.connect('user.db')
#c = conn.cursor()



#encode faces from folder
sfr = Facerec()
sfr.load_encoding_images("images/")

#db = database
det_list=[]
blk_list=[]


def main():
    l1 = sg.Text("Authorized")
    l2 = sg.Text("BlackListed")
    lb1 = sg.Listbox(det_list, size=(35, 7),enable_events=True, key="-LISTBOX-",tooltip="Authorized")
    lb2 = sg.Listbox(blk_list, size=(35, 7),enable_events=True, key="-LISTBOX2-",background_color='red',tooltip="BlackListed")
    col1 = [[l1], [lb1]]
    col2 = [[l2], [lb2]]
    # Define the window's contents
    layout = [
        [sg.Text("Welcome")],
        [sg.Image(key="-IMAGE-", size=(200,200),filename="login.png")],
        [sg.Text("Please enter your login credentials")],
        [sg.Text("Username"), sg.InputText()],
        [sg.Text("Password"), sg.InputText(password_char='*')],
        [sg.Button("Login"), sg.Button("Cancel")]
    ]
    layout1 = [
        [sg.Text("OpenCV Demo", size=(60, 1), justification="center")],
        [sg.Image(filename="", key="-IMAGE-")],
        # [sg.Radio("None", "Radio", True, size=(10, 1))],
        # [
        #     sg.Radio("threshold", "Radio", size=(10, 1), key="-THRESH-"),
        #     sg.Slider(
        #         (0, 255),
        #         128,
        #         1,
        #         orientation="h",
        #         size=(40, 15),
        #         key="-THRESH SLIDER-",
        #     ),
        # ],
        # [
        #     sg.Radio("canny", "Radio", size=(10, 1), key="-CANNY-"),
        #     sg.Slider(
        #         (0, 255),
        #         128,
        #         1,
        #         orientation="h",
        #         size=(20, 15),
        #         key="-CANNY SLIDER A-",
        #     ),
        #     sg.Slider(
        #         (0, 255),
        #         128,
        #         1,
        #         orientation="h",
        #         size=(20, 15),
        #         key="-CANNY SLIDER B-",
        #     ),
        # ],
        # [
        #     sg.Radio("blur", "Radio", size=(10, 1), key="-BLUR-"),
        #     sg.Slider(
        #         (1, 11),
        #         1,
        #         1,
        #         orientation="h",
        #         size=(40, 15),
        #         key="-BLUR SLIDER-",
        #     ),
        # ],
        # [
        #     sg.Radio("hue", "Radio", size=(10, 1), key="-HUE-"),
        #     sg.Slider(
        #         (0, 225),
        #         0,
        #         1,
        #         orientation="h",
        #         size=(40, 15),
        #         key="-HUE SLIDER-",
        #     ),
        # ],
        # [
        #     sg.Radio("enhance", "Radio", size=(10, 1), key="-ENHANCE-"),
        #     sg.Slider(
        #         (1, 255),
        #         128,
        #         1,
        #         orientation="h",
        #         size=(40, 15),
        #         key="-ENHANCE SLIDER-",
        #     ),
        # ],
        #[sg.Text("Detected Occupants : "),sg.InputText()],
        [sg.Text("", size=(0, 1), key='OUTPUT')],
        [sg.Col(col1), sg.Col(col2)],

        ##[[sg.Text('Detected Occupants')], sg.LBox(key="-LIST-",values=det_list)],
        #[sg.Text("Authorized"),sg.Text("BlackListed")],
        #[sg.Listbox(det_list, size=(35, 7),enable_events=True, key="-LISTBOX-",tooltip="Authorized"),
         #sg.Listbox(blk_list, size=(35, 7),enable_events=True, key="-LISTBOX2-",background_color='red',tooltip="BlackListed")],
        [sg.Button("Exit", size=(10, 1))],

    ]

    layout2 = [

    ]
    #layout = 1

    # Create the window
    window = sg.Window("Login Window", layout)



    # Display and interact with the Window using an Event Loop
    while True:
        event, values = window.read()

        # End program if user closes window or
        # presses the Cancel button
        if event == "Cancel" or event == sg.WIN_CLOSED:
            break
        # If user presses the Login button, check if the credentials are valid
        elif event == "Login":
            username = values[0]
            password = values[1]
            # Check if the username and password are valid

            #correct_pwd = db.retrieve_user(username)

            # if password == correct_pwd:
            #     sg.popup("Login successful!")
            #     #window[f'-COL{layout}-'].update(visible=False)
            #     layout = 1
            #     window.close()
            #     #window[f'-COL{layout}-'].update(visible=True)
            #     window = sg.Window("OpenCV Demo", layout1)


            if username == "aaa" and password == "aaa":
                sg.popup("Login successful!")
                #window[f'-COL{layout}-'].update(visible=False)
                layout = 1
                window.close()
                #window[f'-COL{layout}-'].update(visible=True)
                window = sg.Window("OpenCV Demo", layout1)

                opencv(window)

            else:
                sg.popup("Invalid login credentials. Please try again.")

    #conn.commit()
    #conn.close()

    # Close the window
    window.close()

def opencv(window):

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

    cap = cv2.VideoCapture(0)



    while True:

        now = datetime.now()
        date_time = now.strftime("%m/%d/%Y, %H:%M:%S")

        event, values = window.read(timeout=20)

        ret, frame = cap.read()

        # Convert into grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)

        face_locations, face_names = sfr.detect_known_faces(frame)
        # Draw rectangle around the faces
        for face_loc, name in zip(face_locations, face_names):
            # top=y1 left=x1 bottom=y2 right=x2
            y1, x1, y2, x2 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]

            cv2.putText(frame, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 0), 2)
            if "black" in name:
                color = (0,0,200)

            elif "vip" in name:
                color = (200,0,0)
            else:
                color = (0,200,0)

            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 4)

            det_occ = name + " " + date_time
            if "black" in det_occ:
                blk_list.insert(0, det_occ)

            det_list.insert(0,det_occ)


            print(name + " " + date_time)
            occp_rec = name + " " + date_time
            with open('output.txt', 'a') as f:
                f.write(occp_rec + '\n')
                # sys.stdout = f
                # print(occp_rec, end="\n")
                # #print(det_list)
                # sys.stdout = sys.__stdout__


        if event == "Exit" or event == sg.WIN_CLOSED:
            f.close()
            break

        imgbytes = cv2.imencode(".png", frame)[1].tobytes()
        window["-IMAGE-"].update(data=imgbytes)
        #window['OUTPUT'].update(value=det_occ)
        window["-LISTBOX2-"].update(blk_list)
        window["-LISTBOX-"].update(det_list)

    window.close()



main()
