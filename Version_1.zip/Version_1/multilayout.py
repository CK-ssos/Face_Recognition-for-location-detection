import PySimpleGUI as sg
import cv2

file_types = [
    ("JPEG8(*.jpg", "*.jpg"),
    ("All file (*.*)","*.*")
]
def main():

    layout1 = [
        [sg.Text("OpenCV Demo", size=(60, 1), justification="center")],
        [sg.Image(filename="", key="-IMAGE-")],
        [sg.Radio("None", "Radio", True, size=(10, 1))],
        [
            sg.Radio("threshold", "Radio", size=(10, 1), key="-THRESH-"),
            sg.Slider(
                (0, 255),
                128,
                1,
                orientation="h",
                size=(40, 15),
                key="-THRESH SLIDER-",
            ),
        ],
        [
            sg.Radio("canny", "Radio", size=(10, 1), key="-CANNY-"),
            sg.Slider(
                (0, 255),
                128,
                1,
                orientation="h",
                size=(20, 15),
                key="-CANNY SLIDER A-",
            ),
            sg.Slider(
                (0, 255),
                128,
                1,
                orientation="h",
                size=(20, 15),
                key="-CANNY SLIDER B-",
            ),
        ],
        [
            sg.Radio("blur", "Radio", size=(10, 1), key="-BLUR-"),
            sg.Slider(
                (1, 11),
                1,
                1,
                orientation="h",
                size=(40, 15),
                key="-BLUR SLIDER-",
            ),
        ],
        [
            sg.Radio("hue", "Radio", size=(10, 1), key="-HUE-"),
            sg.Slider(
                (0, 225),
                0,
                1,
                orientation="h",
                size=(40, 15),
                key="-HUE SLIDER-",
            ),
        ],
        [
            sg.Radio("enhance", "Radio", size=(10, 1), key="-ENHANCE-"),
            sg.Slider(
                (1, 255),
                128,
                1,
                orientation="h",
                size=(40, 15),
                key="-ENHANCE SLIDER-",
            ),
        ],
        [sg.Button("Exit", size=(10, 1))],
]

    layout2 = [
    [sg.Image(key="-IMAGE-")],
    [
        sg.Text("Image File"),
        sg.Input(size=(25, 1), key="-FILE-"),
        sg.FileBrowse(file_types=file_types),
        sg.Button("Load Image"),
        sg.Button("Save")
    ],
    [sg.Button("Exit", size=(10, 1))],
]

    layout3 = [
        [sg.Text("OpenCV Demo", size=(60, 1), justification="center")],
        [sg.Image(filename="", key="-IMAGE-")],
        [sg.Button("Exit", size=(10, 1))],
    ]

    layout = [
    [sg.Column(layout1, key='-COL1-'), sg.Column(layout2, visible=False, key='-COL2-'), sg.Column(layout3, visible=False, key='-COL3-')],
    [sg.Button('Cycle Layout'), sg.Button('1'), sg.Button('2'), sg.Button('3'), sg.Button('Exit')]
]

    window = sg.Window('Swapping the contents of a window', layout)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

    cap = cv2.VideoCapture(0)

    layout = 1

    while True:
        event, values = window.read()
        print(event, values)
        if event in (None, 'Exit'):
            break
        if event == 'Cycle Layout':
            window[f'-COL{layout}-'].update(visible=False)
            layout = layout + 1 if layout < 3 else 1
            window[f'-COL{layout}-'].update(visible=True)
        elif event in '123':
            window[f'-COL{layout}-'].update(visible=False)
            layout = int(event)
            window[f'-COL{layout}-'].update(visible=True)
        if event == '1':
            event, values = window.read(timeout=20)

            ret, frame = cap.read()

            # Convert into grayscale
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Detect faces
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)

        # Draw rectangle around the faces
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

            if event == "Exit" or event == sg.WIN_CLOSED:
                break

            if values["-THRESH-"]:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)[:, :, 0]
                frame = cv2.threshold(
                    frame, values["-THRESH SLIDER-"], 255, cv2.THRESH_BINARY
                )[1]
            elif values["-CANNY-"]:
                frame = cv2.Canny(
                    frame, values["-CANNY SLIDER A-"], values["-CANNY SLIDER B-"]
                )
            elif values["-BLUR-"]:
                frame = cv2.GaussianBlur(frame, (21, 21), values["-BLUR SLIDER-"])
            elif values["-HUE-"]:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                frame[:, :, 0] += int(values["-HUE SLIDER-"])
                frame = cv2.cvtColor(frame, cv2.COLOR_HSV2BGR)
            elif values["-ENHANCE-"]:
                enh_val = values["-ENHANCE SLIDER-"] / 40
                clahe = cv2.createCLAHE(clipLimit=enh_val, tileGridSize=(8, 8))
                lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
                lab[:, :, 0] = clahe.apply(lab[:, :, 0])
                frame = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

            imgbytes = cv2.imencode(".png", frame)[1].tobytes()
            window["-IMAGE-"].update(data=imgbytes)

    window.close()


main()