import base64

import PySimpleGUI as sg
from PIL import Image
import cv2
import io, os

file_types = [
    ("JPEG8(*.jpg", "*.jpg"),
    ("All file (*.*)","*.*")
]

def main():
    # sg.theme("LightGreen")
    #
    # layout = [
    #     [sg.Text("Show Image", size=(60, 1), justification="center")],
    #     [sg.Input(key="-FILE-"), sg.FileBrowse()],
    #     [sg.Image(key="-IMAGE-")],
    #
    #     [sg.Button("Exit", size=(10, 1))],
    # ]
    #
    # window = sg.Window("Images", layout, location=(800,400))
    #
    # while True:
    #     event, values = window.read(timeout=20)
    #
    #     # If the user closes the window or clicks the "Exit" button, exit the program
    #     if event == sg.WINDOW_CLOSED or event == "Exit":
    #         break
    #
    #     # Otherwise, if an image file was selected, display it in the window
    #     if event == "Browse":
    #         filename = values["-FILE-"]
    #         #image = Image.open(filename)
    #         image = cv2.imread(filename)
    #         image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    #         image = Image.fromarray(image)
    #         image.thumbnail((400, 400))
    #         bio = image.tobytes()
    #         window["-IMAGE-"].update(data=bio)

    layout = [
        [sg.Image(key="-IMAGE-")],
        [
            sg.Text("Image File"),
            sg.Input(size=(25,1), key="-FILE-"),
            sg.FileBrowse(file_types=file_types),
            sg.Button("Load Image"),
            sg.Button("Save")
        ],
        [sg.Button("Exit",size=(10, 1))],
    ]
    window = sg.Window("Import Photo",layout)

    while True:
        event, values = window.read()

        if event == "Exit" or event == sg.WIN_CLOSED:
            break
        # if event == "Load Image":
        #     filename = values["-FILE-"]
        #     if os.path.exists(filename):
        #         image = Image.open(values["-FILE-"])
        #         image.thumbnail((400,400))
        #         bio = io.BytesIO()
        #         image.save(bio, format="PNG")
        #         window("-IMAGE-").update(data=bio.getvalue())

        if event == "Load Image":
            filename = values["-FILE-"]
            if os.path.exists(filename):
                image = Image.open(values["-FILE-"])
                image.thumbnail((400, 400))
                bio = io.BytesIO()
                # Actually store the image in memory in binary
                image.save(bio, format="PNG")
                # Use that image data in order to
                window["-IMAGE-"].update(data=bio.getvalue())
                # Suit for PNG FILE
                #window["-IMAGE-"].update(filename=values["-FILE-"])
        #not working
        elif event == "Save":
            filename = sg.popup_get_file("Save Image As", save_as=True, default_extension=".png")
            if filename:
                if filename:
                    # Get the image element
                    image_element = window["-IMAGE-"]
                    # Get the image's filename
                    original_filename = image_element.Filename
                    # Read the image from the original filename
                    image = Image.open(original_filename)
                    # Create the images directory if it does not exist
                    directory = r"C:\Users\User\PycharmProjects\pythonProject1\FYP\images"
                    os.makedirs(directory, exist_ok=True)
                    # Save the image to disk with the specified filename in the images directory
                    filepath = os.path.join(directory, filename)
                    image.save(filepath)
                # # Get the image data from the window element
                # image_data = window["-IMAGE-"].get_data()
                # # Convert the image data to bytes
                # image_bytes = base64.b64decode(image_data)
                # # Create a BytesIO object with the image bytes
                # bio = io.BytesIO(image_bytes)
                # # Open the image from the binary data
                # image = Image.open(bio)
                # # Save the image to disk with the specified filename
                # image.save(filename)
    window.close()


main()
