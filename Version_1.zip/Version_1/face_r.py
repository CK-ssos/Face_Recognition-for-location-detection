import cv2
import numpy as np
import face_recognition

def main():
    img=face_recognition.load_image_file('images/cks(blacklist).png')
    img_rgb = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
# #--------- Detecting Face -------
#     face = face_recognition.face_locations(img_rgb)[0]
#     copy = img_rgb.copy()

    # --Converting image into encodings
    train_encode = face_recognition.face_encodings(img)[0]
    # ----- lets test an image
    test = face_recognition.load_image_file('images/cks2(blacklist).png')
    test = cv2.cvtColor(test, cv2.COLOR_BGR2RGB)
    test_encode = face_recognition.face_encodings(test)[0]
    print( face_recognition.compare_faces([train_encode], test_encode))

    test2 = face_recognition.load_image_file('images/suhua(whitelist).png')
    test2 = cv2.cvtColor(test2, cv2.COLOR_BGR2RGB)
    test_encode2 = face_recognition.face_encodings(test2)[0]
    print( face_recognition.compare_faces([train_encode], test_encode2))

    test3 = face_recognition.load_image_file('images/tia(VIP).png')
    test3 = cv2.cvtColor(test3, cv2.COLOR_BGR2RGB)
    test_encode3 = face_recognition.face_encodings(test3)[0]
    print( face_recognition.compare_faces([train_encode], test_encode3))

    test4 = face_recognition.load_image_file('images/cks3.png')
    test4 = cv2.cvtColor(test4, cv2.COLOR_BGR2RGB)
    test_encode4 = face_recognition.face_encodings(test4)[0]
    print( face_recognition.compare_faces([train_encode], test_encode4))

    test5 = face_recognition.load_image_file('images/rock.jpg')
    test5 = cv2.cvtColor(test5, cv2.COLOR_BGR2RGB)
    test_encode5 = face_recognition.face_encodings(test5)[0]
    print( face_recognition.compare_faces([test_encode], test_encode5))
# ------ Drawing bounding boxes around Faces------------------------
#     cv2.rectangle(copy, (face[3], face[0]),(face[1], face[2]), (255,0,255), 2)
#     cv2.imshow('copy', copy)
#     cv2.imshow('MODI',img_modi_rgb)
#     cv2.waitKey(0)


main()
