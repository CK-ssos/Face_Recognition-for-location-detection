from PySide2.QtCore import Qt, QDateTime, QRect
from PySide2.QtWidgets import QMainWindow, QApplication, QMessageBox, QTableWidgetItem, QHeaderView, QLabel, QTextEdit
from PySide2.QtSql import QSqlDatabase, QSqlQuery
from PySide2.QtGui import QFont, QPixmap, QImage
from UI_occupant_detail import Ui_MainWindow
from datetime import datetime

class MainOccupants_DetailWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MainOccupants_DetailWindow, self).__init__()

        self.setupUi(self)
        self.setFieldFont()

        self.photo_label = QLabel(self.frame)
        self.photo_label.setScaledContents(True)
        self.photo_label.setGeometry(QRect(0, 0, 240, 260))

        font = QFont()
        font.setPointSize(12)
        self.blacklist.setFont(font)

        self.btn_srch.clicked.connect(self.search_btn_clicked)
        self.btn_flt.clicked.connect(self.filter_table)
        self.blacklist.clicked.connect(self.checkboxClicked)

        self.setFixedSize(self.size())  # Set window size as fixed
        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # Resize columns to fit content

        self.tableWidget.setSortingEnabled(True)
        self.tableWidget.horizontalHeader().sectionClicked.connect(self.sort_table)
        self.tableWidget.setEditTriggers(QHeaderView.NoEditTriggers)

        font = QFont()
        font.setPointSize(12)
        self.tableWidget.setFont(font)

    def set_clicked_item(self, item_name, clicked_OID):
        occupants_data, detected_data = self.retrieve_data_from_tables(clicked_OID)

        if occupants_data is not None and detected_data is not None:
            self.display_data(occupants_data, detected_data)
    def search_btn_clicked(self):
        name = self.input_NID.toPlainText()
        print(name)

        if not name:
            # Handle the case when the name is empty
            QMessageBox.information(None, "Invalid Input", "Please enter an available name or OID.")
            return

        # Clear the table contents
        self.tableWidget.clearContents()
        self.tableWidget.setRowCount(0)

        occupants_data, detected_data = self.retrieve_data_from_tables(name)
        if occupants_data is not None and detected_data is not None:
            self.display_data(occupants_data, detected_data)

            if self.check_blacklist(occupants_data[0]["OID"]):
                self.blacklist.setChecked(True)
            else:
                self.blacklist.setChecked(False)

        else:
            # Handle the case when no data is found
            QMessageBox.information(None, "Data Not Found", "No data found for the entered name or OID.")
            self.clear_displayed_data()
    def clear_displayed_data(self):
        # Clear the displayed data when no data is found
        self.id_in.clear()
        self.name_in.clear()
        self.gender_in.clear()
        self.comp_in.clear()
        self.pos_in.clear()
        self.datereg_in.clear()
        self.photo_label.clear()
        self.tableWidget.clearContents()
        self.tableWidget.setRowCount(0)
    def setFieldFont(self):
        font = QFont()
        font.setPointSize(10)  # Set font size to 10

        textEdits = self.findChildren(QTextEdit)  # Find all QTextEdit widgets

        for textEdit in textEdits:
            textEdit.setFont(font)  # Apply the font to each QTextEdit

    # def set_table_cell_alignment(self, alignment):
    #     row_count = self.tableWidget.rowCount()
    #     column_count = self.tableWidget.columnCount()
    #
    #     for row in range(row_count):
    #         for column in range(column_count):
    #             item = self.tableWidget.item(row, column)
    #             if item is not None:
    #                 item.setTextAlignment(alignment)
    # def set_table_cell_alignment(self, alignment):
    #     row_count = self.tableWidget.rowCount()
    #     column_count = self.tableWidget.columnCount()
    #
    #     for row in range(row_count):
    #         for column in range(column_count):
    #             item = self.tableWidget.item(row, column)
    #             if item is not None:
    #                 item.setTextAlignment(alignment)
    #
    #     # Center align the header contents
    #     header = self.tableWidget.horizontalHeader()
    #     header.setDefaultAlignment(alignment)
    def retrieve_data_from_tables(self, name_or_oid):
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Prepare the query to retrieve data from the Occupants table
        occupants_query = QSqlQuery()
        #occupants_query.prepare("SELECT * FROM Occupants WHERE LOWER(Name) = :name OR LOWER(OccupantsID) = :oid")
        occupants_query.prepare("SELECT * FROM Occupants WHERE Name = :name OR OccupantsID = :oid")
        occupants_query.bindValue(":name", name_or_oid)
        occupants_query.bindValue(":oid", name_or_oid)

        if not occupants_query.exec_():
            print("Failed to execute query for Occupants table.")
            db.close()
            return

        occupants_data = []
        while occupants_query.next():
            # Retrieve the data from the Occupants table
            oid = occupants_query.value("OccupantsID")
            name = occupants_query.value("Name")
            contact = occupants_query.value("Contact")
            dob = occupants_query.value("DOB")
            gender = occupants_query.value("Gender")
            company = occupants_query.value("Company")
            position = occupants_query.value("Position")
            date_accessed = occupants_query.value("DateAccessed")
            photo = occupants_query.value("Photo")
            print(photo)

            occupants_data.append({
                "OID": oid,
                "Name": name,
                "Contact": contact,
                "DOB": dob,
                "Gender": gender,
                "Company": company,
                "Position": position,
                "DateAccessed": date_accessed,
                "Photo" : photo
            })

        # Prepare the query to retrieve data from the Detected_Occ table
        detected_query = QSqlQuery()
        #detected_query.prepare("SELECT * FROM Detected_Occ WHERE LOWER(Name) = :name OR LOWER(OID) = :oid")
        detected_query.prepare("SELECT * FROM Detected_Occ WHERE Name = :name OR OID = :oid")
        detected_query.bindValue(":name", name_or_oid)
        detected_query.bindValue(":oid", name_or_oid)

        if not detected_query.exec_():
            print("Failed to execute query for Detected_Occ table.")
            db.close()
            return

        detected_data = []
        while detected_query.next():
            # Retrieve the data from the Detected_Occ table
            record_id = detected_query.value("RecordID")
            oid = detected_query.value("OID")
            name = detected_query.value("Name")
            contact = detected_query.value("Contact")
            detected_dt = detected_query.value("DetectedDT")
            zone = detected_query.value("Zone")
            status = detected_query.value("Status")

            detected_data.append({
                "RecordID": record_id,
                "OID": oid,
                "Name": name,
                "Contact": contact,
                "DetectedDT": detected_dt,
                "Zone" : zone,
                "Status" : status
            })

        # Close the database connection
        db.close()

        return occupants_data, detected_data
    def display_data(self, occupants_data, detected_data):
        # Display occupants data
        if occupants_data:
            occupant = occupants_data[0]  # Assuming only one occupant is retrieved
            self.id_in.setText(str(occupant["OID"]))
            self.name_in.setText(occupant["Name"])
            self.gender_in.setText(occupant["Gender"])
            self.comp_in.setText(occupant["Company"])
            self.pos_in.setText(occupant["Position"])
            self.datereg_in.setText(occupant["DateAccessed"])

            photo_data = occupant["Photo"]
            # print(photo_data)
            image = QImage.fromData(photo_data)

            if not image.isNull():
                # Scale the image to fit the label size
                scaled_image = image.scaled(self.photo_label.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                            Qt.SmoothTransformation)
                # Create a QPixmap from the scaled image
                pixmap = QPixmap.fromImage(scaled_image)
                self.photo_label.setPixmap(pixmap)

        # Display detected data
        if detected_data:
            self.tableWidget.setRowCount(len(detected_data))
            for row, data in enumerate(detected_data):
                date = data["DetectedDT"]
                zone = data["Zone"]
                status = data["Status"]
                formatted_date = self.change_date_format(date)
                new_date = formatted_date.split(" ")
                #new_date = date.split(" ")
                print(new_date)

                self.tableWidget.setItem(row, 0, QTableWidgetItem(new_date[0]))
                self.tableWidget.setItem(row, 1, QTableWidgetItem(new_date[1]))
                self.tableWidget.setItem(row, 2, QTableWidgetItem(zone))
                self.tableWidget.setItem(row, 3, QTableWidgetItem(status))


                # Set other columns with corresponding data

                # Set the alignment for each cell in the row
                for col, text in enumerate(new_date):
                    item = QTableWidgetItem(text)
                    item.setTextAlignment(Qt.AlignCenter)
                    self.tableWidget.setItem(row, col, item)
                zone_item = QTableWidgetItem(zone)
                zone_item.setTextAlignment(Qt.AlignCenter)
                self.tableWidget.setItem(row, 2, zone_item)

                status_item = QTableWidgetItem(status)
                status_item.setTextAlignment(Qt.AlignCenter)
                self.tableWidget.setItem(row, 3, status_item)
    def filter_table(self):
        filter_text = self.input_NID_2.toPlainText().strip().lower()
        print(filter_text)

        if not filter_text:
            # If the filter text is empty, show all rows in the table
            for row in range(self.tableWidget.rowCount()):
                self.tableWidget.setRowHidden(row, False)
            return
        # Get the column indices to apply the filter
        date_column = 0
        time_column = 1
        zone_column = 2
        status_column = 3

        row_count = self.tableWidget.rowCount()
        for row in range(row_count):
            # Get the text in each cell of the row
            date_text = self.tableWidget.item(row, date_column).text().strip().lower()
            time_text = self.tableWidget.item(row, time_column).text().strip().lower()
            zone_text = self.tableWidget.item(row, zone_column).text().strip().lower()
            status_text = self.tableWidget.item(row, status_column).text().strip().lower()

            # Check if the filter text is present in any of the columns
            if (filter_text in date_text) or (filter_text in time_text) or (filter_text in zone_text) or (filter_text in status_text):
                self.tableWidget.setRowHidden(row, False)
            else:
                self.tableWidget.setRowHidden(row, True)
    def sort_table(self, index):
        # Initialize the sort order dictionary if it doesn't exist
        if not hasattr(self, "sort_order_dict"):
            self.sort_order_dict = {}

        # Get the current sort order of the clicked column
        current_sort_order = self.sort_order_dict.get(index, Qt.SortOrder.AscendingOrder)

        # Determine the new sort order for the clicked column
        if current_sort_order == Qt.SortOrder.AscendingOrder:
            new_sort_order = Qt.SortOrder.DescendingOrder
        else:
            new_sort_order = Qt.SortOrder.AscendingOrder

        # Update the sort order for the clicked column in the dictionary
        self.sort_order_dict[index] = new_sort_order

        # Update the sort order for the clicked column in the table
        self.tableWidget.sortByColumn(index, new_sort_order)

        # Set the sort order arrow for the clicked column
        self.tableWidget.horizontalHeader().setSortIndicator(index, new_sort_order)
        self.tableWidget.horizontalHeader().setSortIndicatorShown(True)

        # If the column clicked is the date column (let's assume it's column 0)
        if index == 0:
            self.tableWidget.sortByColumn(index, new_sort_order, lambda row: self.get_sort_date(row, index))
    def get_sort_date(self, row, column):
        # This function returns a sort key for the date column
        date_item = self.tableWidget.item(row, column)
        time_item = self.tableWidget.item(row, column + 1)  # Assuming time is in the next column (column + 1)
        if date_item and time_item:
            date_str = date_item.text()
            time_str = time_item.text()
            # Combine the date and time strings into a single datetime string
            datetime_str = f"{date_str} {time_str}"
            # Parse the datetime string into a QDateTime object
            datetime = QDateTime.fromString(datetime_str, "yyyy-MM-dd HH:mm:ss")
            return datetime
        return None
    def change_date_format(self, input_date):
        # Parse the input date using the original format
        input_format = "%m/%d/%Y %H:%M:%S"
        date_obj = datetime.strptime(input_date, input_format)

        # Format the date to the desired format
        output_format = "%d-%m-%Y %H:%M:%S"
        formatted_date = date_obj.strftime(output_format)

        return formatted_date
    def create_blacklist_table(self):
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")

        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to create the "Detected_Occ" table
        query = QSqlQuery()
        query.prepare(
            '''CREATE TABLE IF NOT EXISTS Blacklist(
                     BKID INTEGER PRIMARY KEY AUTOINCREMENT,
                     OID INTEGER,
                     Name VARCHAR(255),
                     BlacklistedDT DATETIME
                     )
                     ''')

        if not query.exec_():
            print("Failed to create the Blacklist table.")
            db.close()
            return

        # Close the database connection
        db.close()
    def retrieve_blacklist_data(self):
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")

        if not db.open():
            print("Failed to connect to the database.")
            return None

        blacklist_data = []

        # Execute a query to retrieve data from the "Blacklist" table
        query = QSqlQuery()
        query.prepare("SELECT BKID, OID, Name, BlacklistedDT FROM Blacklist")

        if query.exec_():
            while query.next():
                bk_id = query.value(0)
                oid = query.value(1)
                name = query.value(2)
                blacklist_dt = query.value(3)
                blacklist_data.append((bk_id, oid, name, blacklist_dt))
        else:
            print("Failed to retrieve data from the Blacklist table.")

        # Close the database connection
        db.close()
        return blacklist_data
    def checkboxClicked(self):
        if self.blacklist.isChecked():
            confirmation = QMessageBox.question(self, "Confirmation", "Are you sure you want to add the occupant into BLACKLIST?",
                                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if confirmation == QMessageBox.Yes:
                occupant_id = int(self.id_in.toPlainText())
                occupant_name = self.name_in.toPlainText()

                current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                db = QSqlDatabase.addDatabase("QSQLITE")
                db.setDatabaseName("Occupants.db")

                if not db.open():
                    print("Failed to connect to the database.")
                    return

                query = QSqlQuery()
                query.prepare("INSERT INTO Blacklist (OID, Name, BlacklistedDT) VALUES (:oid, :name, :blacklisted_dt)")
                query.bindValue(":oid", occupant_id)
                query.bindValue(":name", occupant_name)
                query.bindValue(":blacklisted_dt", current_datetime)

                if not query.exec_():
                    print("Failed to add occupant to Blacklist table.")
                    db.close()
                    return
                # Close the database connection
                db.close()
                print("Occupant added to Blacklist")

            else:
                self.blacklist.setChecked(False)
                print("Action Fail")

        else:
            confirmation = QMessageBox.question(self, "Confirmation", "Are you sure you want to remove occupant from BLACKLIST?",
                                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            if confirmation == QMessageBox.Yes:
                occupant_id = int(self.id_in.toPlainText())

                db = QSqlDatabase.addDatabase("QSQLITE")
                db.setDatabaseName("Occupants.db")

                if not db.open():
                    print("Failed to connect to the database.")
                    return

                query = QSqlQuery()
                query.prepare("DELETE FROM Blacklist WHERE OID = :oid")
                query.bindValue(":oid", occupant_id)

                if not query.exec_():
                    print("Failed to remove occupant from Blacklist table.")
                    db.close()
                    return

                db.close()
                print("Occupant removed from Blacklist")
            else:
                self.blacklist.setChecked(True)
                print("Action Remove Fail")
    def check_blacklist(self, oid):
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return False

        query = QSqlQuery()
        query.prepare("SELECT COUNT(*) FROM Blacklist WHERE OID = :oid")
        query.bindValue(":oid", oid)

        if not query.exec_():
            print("Failed to check if occupant is in Blacklist.")
            db.close()
            return False

        query.next()
        count = query.value(0)

        db.close()
        return count > 0

if __name__ == "__main__":
    app = QApplication([])
    window = MainOccupants_DetailWindow()
    window.show()
    app.exec_()



