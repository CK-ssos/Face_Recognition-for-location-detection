# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'add_occupantsNkiuTn.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1449, 865)
        # self.actionMain = QAction(MainWindow)
        # self.actionMain.setObjectName(u"actionMain")
        # self.actionLV01 = QAction(MainWindow)
        # self.actionLV01.setObjectName(u"actionLV01")
        # self.actionLV01_02 = QAction(MainWindow)
        # self.actionLV01_02.setObjectName(u"actionLV01_02")
        # self.actionView_Records = QAction(MainWindow)
        # self.actionView_Records.setObjectName(u"actionView_Records")
        # self.actionCompany_Details = QAction(MainWindow)
        # self.actionCompany_Details.setObjectName(u"actionCompany_Details")
        # self.actionOccupants_Details = QAction(MainWindow)
        # self.actionOccupants_Details.setObjectName(u"actionOccupants_Details")
        # self.actionUser_Authentication = QAction(MainWindow)
        # self.actionUser_Authentication.setObjectName(u"actionUser_Authentication")
        # self.actionCamera_Setting = QAction(MainWindow)
        # self.actionCamera_Setting.setObjectName(u"actionCamera_Setting")
        # self.actionLV02_01 = QAction(MainWindow)
        # self.actionLV02_01.setObjectName(u"actionLV02_01")
        # self.actionLV02_02 = QAction(MainWindow)
        # self.actionLV02_02.setObjectName(u"actionLV02_02")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.btn_dlt = QPushButton(self.centralwidget)
        self.btn_dlt.setObjectName(u"btn_dlt")
        self.btn_dlt.setGeometry(QRect(1160, 780, 81, 28))
        self.btn_refresh = QPushButton(self.centralwidget)
        self.btn_refresh.setObjectName(u"btn_refresh")
        self.btn_refresh.setGeometry(QRect(1250, 780, 81, 28))
        self.btn_bck = QPushButton(self.centralwidget)
        self.btn_bck.setObjectName(u"btn_bck")
        self.btn_bck.setGeometry(QRect(1340, 780, 81, 28))
        self.textBrowser = QTextBrowser(self.centralwidget)
        self.textBrowser.setObjectName(u"textBrowser")
        self.textBrowser.setGeometry(QRect(0, 0, 241, 41))
        self.formLayoutWidget = QWidget(self.centralwidget)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(740, 30, 671, 331))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.textBrowser_3 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_3.setObjectName(u"textBrowser_3")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.textBrowser_3)

        self.OID = QTextEdit(self.formLayoutWidget)
        self.OID.setObjectName(u"OID")

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.OID)

        self.textBrowser_2 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_2.setObjectName(u"textBrowser_2")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.textBrowser_2)

        self.ip_name = QTextEdit(self.formLayoutWidget)
        self.ip_name.setObjectName(u"ip_name")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.ip_name)

        self.textBrowser_8 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_8.setObjectName(u"textBrowser_8")

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.textBrowser_8)

        self.ip_contact = QTextEdit(self.formLayoutWidget)
        self.ip_contact.setObjectName(u"ip_contact")

        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.ip_contact)

        self.textBrowser_5 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_5.setObjectName(u"textBrowser_5")

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.textBrowser_5)

        self.dateEdit = QDateEdit(self.formLayoutWidget)
        self.dateEdit.setObjectName(u"dateEdit")

        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.dateEdit)

        self.textBrowser_7 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_7.setObjectName(u"textBrowser_7")

        self.formLayout.setWidget(5, QFormLayout.LabelRole, self.textBrowser_7)

        self.ip_comp = QTextEdit(self.formLayoutWidget)
        self.ip_comp.setObjectName(u"ip_comp")

        self.formLayout.setWidget(5, QFormLayout.FieldRole, self.ip_comp)

        self.textBrowser_6 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_6.setObjectName(u"textBrowser_6")

        self.formLayout.setWidget(6, QFormLayout.LabelRole, self.textBrowser_6)

        self.ip_pos = QTextEdit(self.formLayoutWidget)
        self.ip_pos.setObjectName(u"ip_pos")

        self.formLayout.setWidget(6, QFormLayout.FieldRole, self.ip_pos)

        self.textBrowser_4 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_4.setObjectName(u"textBrowser_4")

        self.formLayout.setWidget(7, QFormLayout.LabelRole, self.textBrowser_4)

        self.ip_dateacc = QTextEdit(self.formLayoutWidget)
        self.ip_dateacc.setObjectName(u"ip_dateacc")

        self.formLayout.setWidget(7, QFormLayout.FieldRole, self.ip_dateacc)

        self.textBrowser_9 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_9.setObjectName(u"textBrowser_9")

        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.textBrowser_9)

        self.ip_gender = QTextEdit(self.formLayoutWidget)
        self.ip_gender.setObjectName(u"ip_gender")

        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.ip_gender)

        self.btn_update = QPushButton(self.centralwidget)
        self.btn_update.setObjectName(u"btn_update")
        self.btn_update.setGeometry(QRect(1260, 370, 81, 28))
        self.btn_add = QPushButton(self.centralwidget)
        self.btn_add.setObjectName(u"btn_add")
        self.btn_add.setGeometry(QRect(1350, 370, 81, 28))
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(49, 59, 651, 331))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.upload_photo = QPushButton(self.centralwidget)
        self.upload_photo.setObjectName(u"upload_photo")
        self.upload_photo.setGeometry(QRect(600, 370, 93, 28))
        self.scrollArea = QScrollArea(self.centralwidget)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setGeometry(QRect(29, 406, 1381, 361))
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 1379, 359))
        self.tableWidget = QTableWidget(self.scrollAreaWidgetContents)
        if (self.tableWidget.columnCount() < 8):
            self.tableWidget.setColumnCount(8)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(7, __qtablewidgetitem7)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(-5, 0, 1391, 365))
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        # self.menuBar = QMenuBar(MainWindow)
        # self.menuBar.setObjectName(u"menuBar")
        # self.menuBar.setGeometry(QRect(0, 0, 1449, 26))
        # self.menuENTRANCE = QMenu(self.menuBar)
        # self.menuENTRANCE.setObjectName(u"menuENTRANCE")
        # self.menuLV01 = QMenu(self.menuENTRANCE)
        # self.menuLV01.setObjectName(u"menuLV01")
        # self.menuLV02 = QMenu(self.menuENTRANCE)
        # self.menuLV02.setObjectName(u"menuLV02")
        # self.menuview = QMenu(self.menuBar)
        # self.menuview.setObjectName(u"menuview")
        # self.menuUSER = QMenu(self.menuBar)
        # self.menuUSER.setObjectName(u"menuUSER")
        # self.menuSETTING = QMenu(self.menuBar)
        # self.menuSETTING.setObjectName(u"menuSETTING")
        # self.menuOccupants = QMenu(self.menuBar)
        # self.menuOccupants.setObjectName(u"menuOccupants")
        # MainWindow.setMenuBar(self.menuBar)
        #
        # self.menuBar.addAction(self.menuENTRANCE.menuAction())
        # self.menuBar.addAction(self.menuview.menuAction())
        # self.menuBar.addAction(self.menuUSER.menuAction())
        # self.menuBar.addAction(self.menuOccupants.menuAction())
        # self.menuBar.addAction(self.menuSETTING.menuAction())
        # self.menuENTRANCE.addAction(self.menuLV01.menuAction())
        # self.menuENTRANCE.addAction(self.menuLV02.menuAction())
        # self.menuLV01.addAction(self.actionLV01)
        # self.menuLV01.addAction(self.actionLV01_02)
        # self.menuLV02.addAction(self.actionLV02_01)
        # self.menuLV02.addAction(self.actionLV02_02)
        # self.menuview.addAction(self.actionView_Records)
        # self.menuUSER.addAction(self.actionUser_Authentication)
        # self.menuSETTING.addAction(self.actionCamera_Setting)
        # self.menuOccupants.addAction(self.actionCompany_Details)
        # self.menuOccupants.addAction(self.actionOccupants_Details)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        # self.actionMain.setText(QCoreApplication.translate("MainWindow", u"Main", None))
        # self.actionLV01.setText(QCoreApplication.translate("MainWindow", u"LV01_01", None))
        # self.actionLV01_02.setText(QCoreApplication.translate("MainWindow", u"LV01_02", None))
        # self.actionView_Records.setText(QCoreApplication.translate("MainWindow", u"View Records", None))
        # self.actionCompany_Details.setText(QCoreApplication.translate("MainWindow", u"Company Details", None))
        # self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))
        # self.actionUser_Authentication.setText(QCoreApplication.translate("MainWindow", u"User Authentication", None))
        # self.actionCamera_Setting.setText(QCoreApplication.translate("MainWindow", u"Camera Setting", None))
        # self.actionLV02_01.setText(QCoreApplication.translate("MainWindow", u"LV02_01", None))
        # self.actionLV02_02.setText(QCoreApplication.translate("MainWindow", u"LV02_02", None))
        self.btn_dlt.setText(QCoreApplication.translate("MainWindow", u"Delete", None))
        self.btn_refresh.setText(QCoreApplication.translate("MainWindow", u"Refresh", None))
        self.btn_bck.setText(QCoreApplication.translate("MainWindow", u"Back", None))
        self.textBrowser.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600;\">Occupants Record</span></p></body></html>", None))
        self.textBrowser_3.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Occupant ID</span></p></body></html>", None))
        self.OID.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-style:italic; color:#a5a5a5;\">Auto Generate</span></p></body></html>", None))
        self.textBrowser_2.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Name</span></p></body></html>", None))
        self.textBrowser_8.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Contact</span></p></body></html>", None))
        self.textBrowser_5.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Date Of Birth</span></p></body></html>", None))
        self.textBrowser_7.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Company</span></p></body></html>", None))
        self.textBrowser_6.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Position</span></p></body></html>", None))
        self.textBrowser_4.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Date Accessed</span></p></body></html>", None))
        self.ip_dateacc.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-style:italic; color:#b4b4b4;\">Sync Datetime</span></p></body></html>", None))
        self.textBrowser_9.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Gender</span></p></body></html>", None))
        self.btn_update.setText(QCoreApplication.translate("MainWindow", u"Update", None))
        self.btn_add.setText(QCoreApplication.translate("MainWindow", u"Add", None))
        self.upload_photo.setText(QCoreApplication.translate("MainWindow", u"Upload Photo", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"OID", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Name", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Contact", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"DateOfBirth", None));
        ___qtablewidgetitem4 = self.tableWidget.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Gender", None));
        ___qtablewidgetitem5 = self.tableWidget.horizontalHeaderItem(5)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"Company", None));
        ___qtablewidgetitem6 = self.tableWidget.horizontalHeaderItem(6)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"Position", None));
        ___qtablewidgetitem7 = self.tableWidget.horizontalHeaderItem(7)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"DateAccessed", None));
        # self.menuENTRANCE.setTitle(QCoreApplication.translate("MainWindow", u"ENTRANCE", None))
        # self.menuLV01.setTitle(QCoreApplication.translate("MainWindow", u"LV01", None))
        # self.menuLV02.setTitle(QCoreApplication.translate("MainWindow", u"LV02", None))
        # self.menuview.setTitle(QCoreApplication.translate("MainWindow", u"VIEW", None))
        # self.menuUSER.setTitle(QCoreApplication.translate("MainWindow", u"USER", None))
        # self.menuSETTING.setTitle(QCoreApplication.translate("MainWindow", u"SETTING", None))
        # self.menuOccupants.setTitle(QCoreApplication.translate("MainWindow", u"Occupants", None))
    # retranslateUi


