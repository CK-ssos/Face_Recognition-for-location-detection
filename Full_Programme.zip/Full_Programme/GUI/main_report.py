import os
import sys
import re
from io import BytesIO
from PIL import Image
from PySide2.QtGui import QPixmap, QImage, QFontMetrics, QFont, QColor
from PySide2.QtWidgets import QApplication, QMainWindow, QLabel, QFrame, QMessageBox, QAction, QListWidgetItem, \
    QListWidget, QVBoxLayout, QWidget, QGraphicsScene, QDateEdit, QCalendarWidget
from PySide2.QtCore import Qt, QTimer, QRect, QCoreApplication, QDate, QDateTime, QTime
from PySide2.QtSql import QSqlDatabase, QSqlQuery
from datetime import datetime
from main_occupant_detail import MainOccupants_DetailWindow
import csv
import matplotlib
matplotlib.use('Qt5Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import pandas as pd

from UI_report import UI_ReportWindow

class MatplotlibGraph(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout(self)
        self.canvas = FigureCanvas(plt.figure())
        layout.addWidget(self.canvas)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.update_figure_size()
    def update_figure_size(self):
        self.canvas.figure.set_size_inches(5,3.8)
        self.canvas.draw()
    def clear(self):
        self.canvas.figure.clear()
        self.canvas.draw()
    def plot_bar(self, data, report_type):
        self.clear()
        df = pd.DataFrame(data, columns=['Name', 'LastDetectedDT', 'Status'])
        df['LastDetectedDT'] = pd.to_datetime(df['LastDetectedDT'])
        df = df[df['Status'] == 'IN']

        if report_type == 'day':
            df['Date'] = df['LastDetectedDT'].dt.strftime('%d/%m')
            df['Date'] = df['LastDetectedDT'].dt.date
            min_date = df['Date'].min()
            max_date = df['Date'].max()
            complete_date_range = pd.date_range(min_date, max_date, freq='D').date
        elif report_type == 'month':
            df['Date'] = df['LastDetectedDT'].dt.strftime('%B')
        elif report_type == 'year':
            df['Date'] = df['LastDetectedDT'].dt.strftime('%Y')

        df = self.drop_duplicates_by_name_and_date(df)

        grouped_data = df.groupby('Date')['Name'].count()

        if report_type == 'day':
            grouped_data = grouped_data.reindex(complete_date_range, fill_value=0)

        ax = self.canvas.figure.add_subplot(111)
        grouped_data.plot(kind='bar', ax=ax)
        ax.set_title('Counted Occupancies in Building')
        ax.set_xlabel('Date')
        ax.set_ylabel('Count')
        self.update_figure_size()
    def plot_line(self, data, selected_date):
        self.clear()
        df = pd.DataFrame(data, columns=['Name', 'DetectedDT', 'Status'])
        df['DetectedDT'] = pd.to_datetime(df['DetectedDT'])
        df = df[df['Status'] == 'IN']
        print(df)
        df['Date'] = df['DetectedDT'].dt.date  # Create the 'Date' column
        df = df[df['Date'] == selected_date]

        print("Today Data Befor Drop\n",df )

        df = self.drop_duplicates_by_name_and_hour(df)
        # Filter data for the selected date
        df_selected_date = df[df['Date'] == selected_date]
        print("After DROP___\n",df_selected_date)
        print(selected_date)

        if not df_selected_date.empty:
            hourly_count = df_selected_date.groupby(df_selected_date['DetectedDT'].dt.hour)['Name'].count()

            fig, ax = plt.subplots()
            ax.xaxis.set_major_locator(plt.MultipleLocator(base=1))  # Set locator for each hour
            ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{int(x):02}:00'))  # Format to 24-hour time

            unique_hours = df_selected_date['DetectedDT'].dt.hour.unique()
            y_values = [int(hourly_count.get(hour, 0)) for hour in unique_hours]  # Ensure integer value

            ax.plot(unique_hours, y_values, marker='o')

            ax.set_title('Occupants Availability')
            ax.set_xlabel('Time')
            ax.set_ylabel('Number of Occupants')

            self.canvas.figure = fig
            self.canvas.draw()

    # def no_record_message(self):
    #     self.clear()
    #
    #     self.figure.text(0.5, 0.5, "No Record", ha='center', va='center', fontsize=12)
    #     self.draw()

    def drop_duplicates_by_name_and_date(self, df):
        unique_records = {}
        for index, row in df.iterrows():
            key = (row['Name'], row['Date'])
            if key not in unique_records:
                unique_records[key] = index

        return df.loc[unique_records.values()]

    def drop_duplicates_by_name_and_hour(self, df):
        unique_records = {}
        for index, row in df.iterrows():
            key = (row['Name'], row['DetectedDT'].hour)
            if key not in unique_records:
                unique_records[key] = index

        return df.loc[unique_records.values()]

class MainReport_Window(QMainWindow, UI_ReportWindow):
    def __init__(self):
        super(MainReport_Window, self).__init__()

        self.setupUi(self)
        self.setFixedSize(self.size())
        self.detail_window = None
        self.graph_widget = MatplotlibGraph()
        self.att_view.setScene(QGraphicsScene(self))
        self.att_view.scene().addWidget(self.graph_widget)
        self.att_view.setFixedSize(550, 450)

        self.graph_widget2 = MatplotlibGraph()
        self.daytime_view.setScene(QGraphicsScene(self))
        self.daytime_view.scene().addWidget(self.graph_widget2)
        self.daytime_view.setFixedSize(550, 450)

        self.fromLabel.hide()
        self.fromDateEdit.hide()
        self.toLabel.hide()
        self.toDateEdit.hide()
        self.nameLabel.hide()
        self.nameComboBox.hide()
        self.btn_export.hide()

        self.selectDataComboBox.currentTextChanged.connect(self.selectdata)

        self.textBrowser_2.setFixedHeight(40)
        self.att_view.setFixedSize(550, 430)
        self.daytime_view.setFixedSize(550,430)

        current_date = datetime.now().date()

        self.retrieve_data_from_detected_occ_database()
        self.dateEdit.dateChanged.connect(self.show_line_plot)

        self.dateEdit.setCalendarPopup(True)
        self.dateEdit.setDate(QDate.currentDate())

        self.fromDateEdit.setCalendarPopup(True)
        self.fromDateEdit.setDate(QDate.currentDate())

        self.toDateEdit.setCalendarPopup(True)
        self.toDateEdit.setDate(QDate.currentDate())

        self.day_report()
        self.r_day.setChecked(True)
        self.r_day.toggled.connect(self.day_report)
        self.r_month.toggled.connect(self.month_report)
        self.r_year.toggled.connect(self.year_report)
        self.listWidget.itemClicked.connect(self.click_list_item)

        self.retrieve_data_from_detected_trans_database()
        self.time_timer = QTimer()
        self.time_timer.timeout.connect(self.report_notification)
        self.time_timer.start(1000)
        #self.generate_report()

    # def day_report(self):
    #     data = self.retrieve_data_from_database()
    #
    #     if data:
    #         self.graph_widget.plot(data)
    def selectdata(self):
        self.fromLabel.hide()
        self.fromDateEdit.hide()
        self.toLabel.hide()
        self.toDateEdit.hide()
        self.nameLabel.hide()
        self.nameComboBox.hide()
        self.btn_export.hide()
        sltitem = self.selectDataComboBox.currentText()
        if sltitem == " ":
            return

        elif sltitem == "Occupant Detail":
            self.nameLabel.show()
            self.nameComboBox.show()
            self.btn_export.show()
            self.add_name_to_combobox()
            self.btn_export.clicked.connect(self.export_occ_det_record)

        elif sltitem == "Building's Occupants":
            self.btn_export.show()
            self.btn_export.clicked.connect(self.export_building_data_to_csv)

        elif sltitem == "Detected Occupants Record":
            self.toLabel.show()
            self.toDateEdit.show()
            self.fromDateEdit.show()
            self.fromLabel.show()
            self.btn_export.show()
            self.btn_export.clicked.connect(self.export_building_record)
        # else:
        #     self.fromLabel.show()
        #     self.fromDateEdit.show()
        #     self.toLabel.show()
        #     self.toDateEdit.show()
        #     self.nameLabel.show()
        #     self.nameComboBox.show()
        #     self.btn_export.show()
    def day_report(self):
        data = self.retrieve_data_from_detected_trans_database()
        if data:
            self.graph_widget.plot_bar(data, 'day')
    def month_report(self):
        if self.r_month.isChecked():
            data = self.retrieve_data_from_detected_trans_database(monthly=True)
            if data:
                self.graph_widget.plot_bar(data, 'month')
    def year_report(self):
        if self.r_year.isChecked():
            data = self.retrieve_data_from_detected_trans_database(yearly=True)
            if data:
                self.graph_widget.plot_bar(data, 'year')
    # def retrieve_data_from_database(self):
    #     try:
    #         # Connect to the database
    #         conn = QSqlDatabase.addDatabase("QSQLITE")
    #         conn.setDatabaseName("Occupants.db")
    #         if not conn.open():
    #             print("Failed to connect to the database.")
    #             return []
    #
    #         # Execute a SELECT query to retrieve the data from Detected_Occ table
    #         query = QSqlQuery()
    #         query.prepare("SELECT Name, LastDetectedDT, Status FROM Detected_Trans")
    #         if not query.exec_():
    #             print("Failed to execute the query:", query.lastError().text())
    #             conn.close()
    #             return []
    #
    #         data = []
    #         while query.next():
    #             name = query.value(0)
    #             detected_dt = query.value(1)
    #             status = query.value(2)
    #             data.append((name, detected_dt, status))
    #
    #         # Close the database connection
    #         conn.close()
    #
    #         return data
    #     except Exception as e:
    #         print("Error retrieving data from database:", e)
    #
    #     return []
    def retrieve_data_from_detected_trans_database(self, monthly=False, yearly=False):
        try:
            # Connect to the database
            conn = QSqlDatabase.addDatabase("QSQLITE")
            conn.setDatabaseName("Occupants.db")
            if not conn.open():
                print("Failed to connect to the database.")
                return []

            # Execute a SELECT query to retrieve the data from Detected_Trans table
            query = QSqlQuery()
            if monthly:
                query.prepare("SELECT Name, LastDetectedDT, Status, strftime('%Y-%m', LastDetectedDT) AS MonthYear FROM Detected_Trans")
            elif yearly:
                query.prepare("SELECT Name, LastDetectedDT, Status, strftime('%Y', LastDetectedDT) AS Year FROM Detected_Trans")
            else:
                query.prepare("SELECT Name, LastDetectedDT, Status FROM Detected_Trans")

            if not query.exec_():
                print("Failed to execute the query:", query.lastError().text())
                conn.close()
                return []

            data = []
            while query.next():
                name = query.value(0)
                detected_dt = query.value(1)
                status = query.value(2)
                data.append((name, detected_dt, status))

            # Close the database connection
            conn.close()

            return data
        except Exception as e:
            print("Error retrieving data from database:", e)

        return []
    def retrieve_data_from_detected_occ_database(self):
            try:
                # Connect to the database
                conn = QSqlDatabase.addDatabase("QSQLITE")
                conn.setDatabaseName("Occupants.db")
                if not conn.open():
                    print("Failed to connect to the database.")
                    return []

                # Execute a SELECT query to retrieve the data from Detected_Occ table
                query = QSqlQuery()
                query.prepare("SELECT Name, DetectedDT, Status FROM Detected_Occ")
                if not query.exec_():
                    print("Failed to execute the query:", query.lastError().text())
                    conn.close()
                    return []

                data = []
                while query.next():
                    name = query.value(0)
                    detected_dt = query.value(1)
                    status = query.value(2)
                    data.append((name, detected_dt, status))

                # Close the database connection
                conn.close()

                self.detected_occ_data = data  # Replace 'data' with the actual data you retrieve
            except Exception as e:
                print("Error retrieving data from database:", e)
                self.detected_occ_data = []

    def show_line_plot(self, selected_date):
        # if self.detected_occ_data:
        self.graph_widget2.plot_line(self.detected_occ_data, selected_date.toPython())
        # else:
        #     self.graph_widget2.clear()
            #self.graph_widget2.no_record_message()

    # def report_notification(self):
    #     occ_status_data = self.retrieve_occ_status()
    #
    #     self.listWidget.clear()
    #
    #     current_datetime = datetime.now()
    #
    #     for data in occ_status_data:
    #         oid = data["OID"]
    #         status = data["Status"]
    #         zone = data["Zone"]
    #         lastdt = data["LastDT"]
    #
    #         lastdt_obj = datetime.strptime(lastdt, "%m/%d/%Y %H:%M:%S")
    #         time_difference = current_datetime - lastdt_obj
    #
    #         if status == "IN" and time_difference.days >= 2:
    #             item_text = f"OID: {oid}\nStatus: {status}\nZone: {zone}\nLastDT: {lastdt}\n"
    #             item = QListWidgetItem(item_text)
    #             item.setBackground(QColor(255, 200, 200))
    #
    #             self.listWidget.addItem(item)
    def report_notification(self):
        occ_status_data = self.retrieve_occ_status()

        self.listWidget.clear()

        for data in occ_status_data:
            oid = data["OID"]
            name = data["Name"]
            zone = data["Zone"]
            lastdt = data["LastDT"]
            status = data["Status"]

            is_blacklisted = self.check_blacklist(name)

            if status == "IN":
                #print(oid)
                lastdt_obj = datetime.strptime(lastdt, "%m/%d/%Y %H:%M:%S")  # Use the correct format here

                current_datetime = datetime.now()
                time_difference = current_datetime - lastdt_obj
                #print(time_difference)

                if time_difference.days > 2:
                    item_text = f"Warning!!!\nOID: {oid} {name} was IN the building more than 2 days !\n    Last Detected Date: {lastdt}"
                    item = QListWidgetItem(item_text)
                    item.setBackground(QColor(255, 165, 0))
                    self.listWidget.addItem(item)

            if is_blacklisted:
                item_text = f"Warning!!! Blacklist Detected!!!\n BlackListed Person OID: {oid} {name} was IN the building !\n    Last Detected Date: {lastdt}"
                item = QListWidgetItem(item_text)
                item.setBackground(QColor(255, 200, 200))
                self.listWidget.addItem(item)
    def retrieve_occ_status(self):
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("Occupants.db")
            if not db.open():
                print("Failed to connect to the database.")
                return []

            query = QSqlQuery()
            query.prepare("SELECT * FROM occ_status")
            if not query.exec_():
                print("Failed to fetch records from occ_status table.")
                db.close()
                return []

            occ_status_data = []

            while query.next():
                oid = query.value(0)
                name = query.value(1)
                lastdt = query.value(2)
                status = query.value(3)
                zone = query.value(4)
                occ_status_data.append({"OID": oid, "Name": name, "LastDT": lastdt, "Status":status, "Zone": zone})

            db.close()
            return occ_status_data

    def check_blacklist(self, facename):
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")

        if not db.open():
            print("Failed to connect to the database.")
            return False

        query = QSqlQuery()
        query.prepare("SELECT COUNT(*) FROM Blacklist WHERE NAME = :name")
        query.bindValue(":name", facename)

        if not query.exec_():
            print("Failed to check if occupant is in Blacklist.")
            db.close()
            return False

        query.next()
        count = query.value(0)

        db.close()
        return count > 0

    def click_list_item(self, item):
        # Access the clicked item
        clickedItem = item.text()

        print(clickedItem)
        match = re.search(r"\b\d+\b", clickedItem)
        if match:
            clicked_OID = match.group()
            print(clicked_OID)
        # If the detail window doesn't exist or has been closed, create a new instance
        if not self.detail_window or not self.detail_window.isVisible():
            self.detail_window = MainOccupants_DetailWindow()
        # Set the clicked item name in the detail window
        self.detail_window.set_clicked_item(clickedItem, clicked_OID)
        # Show the detail window
        self.detail_window.show()

    def export_building_data_to_csv(self):
        csv_filename = "occupants_data.csv"
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        query.prepare("SELECT * FROM Occupants")
        if not query.exec_():
            print("Failed to fetch records.")
            db.close()
            return

        image_directory = "image_exports"
        if not os.path.exists(image_directory):
            os.makedirs(image_directory)

        # Fetch data and write to CSV
        with open(csv_filename, "w", newline="") as csv_file:
            csv_writer = csv.writer(csv_file)

            # header
            field_names = [query.record().fieldName(i) for i in range(query.record().count())]
            csv_writer.writerow(field_names)
            # data
            while query.next():
                row = [query.value(i) for i in range(query.record().count())]

                # Convert image blob data to image and save temporarily
                image_blob_data = query.value(field_names.index("Photo"))
                if image_blob_data is not None:
                    image = Image.open(BytesIO(image_blob_data))
                    image_name = query.value(field_names.index("Name"))
                    image_filename = f"{image_name}.jpg"

                    image_path = os.path.join(image_directory, image_filename)
                    # Convert RGBA image to RGB mode
                    if image.mode == "RGBA":
                        image = image.convert("RGB")

                    image.save(image_path)
                    row[field_names.index("Photo")] = image_filename

                csv_writer.writerow(row)

        print(f"Data exported to {csv_filename} successfully.")

        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setWindowTitle("Export Successful")
        msg_box.setText(f"Data exported to {csv_filename} successfully.")
        msg_box.exec_()

        db.close()

    def export_building_record(self):
        csv_filename = "building_detected_record.csv"

        # Get start and end dates from the QDateEdit widgets
        start_date = self.fromDateEdit.date().toPython()
        end_date = self.toDateEdit.date().toPython()

        try:
            # Connect to the database
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("Occupants.db")
            if not db.open():
                print("Failed to connect to the database.")
                return

            start_date = QDate(start_date).toPython()
            end_date = QDate(end_date).toPython()

            start_datetime = QDateTime(start_date, QTime(0, 0, 0))
            end_datetime = QDateTime(end_date, QTime(23, 59, 59))
            db_date_format = "MM/dd/yyyy"
            formatted_start_date = start_datetime.toString(db_date_format + " hh:mm:ss")
            formatted_end_date = end_datetime.toString(db_date_format + " hh:mm:ss")
            # Execute a SELECT query to retrieve the data from Detected_Occ table within the date range
            query = QSqlQuery()
            query.prepare("SELECT * FROM Detected_Occ WHERE DetectedDT BETWEEN :start_date AND :end_date")
            query.bindValue(":start_date", formatted_start_date)
            query.bindValue(":end_date", formatted_end_date)
            if not query.exec_():
                print("Failed to execute the query:", query.lastError().text())
                db.close()
                return

            data = []
            while query.next():
                record_id = query.value(0)
                oid = query.value(1)
                name = query.value(2)
                contact = query.value(3)
                detected_dt = query.value(4)
                photo_blob = query.value(5)
                zone = query.value(6)
                status = query.value(7)
                data.append((record_id, oid, name, contact, detected_dt, zone, status))

            # Close the database connection
            db.close()

            if not data:
                print("No data found within the specified date range.")
                return

            # Fetch data and write to CSV
            with open(csv_filename, "w", newline="") as csv_file:
                csv_writer = csv.writer(csv_file)

                # Write header
                field_names = ["RecordID", "OID", "Name", "Contact", "DetectedDT", "Zone", "Status"]
                csv_writer.writerow(field_names)

            # Write data
                for row in data:
                    csv_writer.writerow(row)

            print(f"Data exported to {csv_filename} successfully.")
            msg_box = QMessageBox()
            msg_box.setIcon(QMessageBox.Information)
            msg_box.setWindowTitle("Export Successful")
            msg_box.setText(f"Data exported to {csv_filename} successfully.")
            msg_box.exec_()

        except Exception as e:
            print("Error retrieving and exporting data:", e)

    def add_name_to_combobox(self):
        try:
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("Occupants.db")
            if not db.open():
                print("Failed to connect to the database.")
                return

            query = QSqlQuery()
            query.prepare("SELECT Name FROM Occupants")
            if not query.exec_():
                print("Failed to execute the query:", query.lastError().text())
                db.close()
                return

            self.nameComboBox.clear()

            while query.next():
                name = query.value(0)
                self.nameComboBox.addItem(name)

            db.close()
        except Exception as e:
            print("Error retrieving 'Name' values from database:", e)

    def export_occ_det_record(self):
        selected_name = self.nameComboBox.currentText()
        if not selected_name:
            print("No name selected.")
            return

        csv_filename = f"{selected_name}.csv"
        try:
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("Occupants.db")
            if not db.open():
                print("Failed to connect to the database.")
                return

            # Execute a SELECT query to retrieve the data from Detected_Occ table within the date range
            query = QSqlQuery()
            query.prepare("SELECT * FROM Detected_Occ WHERE Name = :selected_name")
            query.bindValue(":selected_name", selected_name)
            if not query.exec_():
                print("Failed to execute the query:", query.lastError().text())
                db.close()
                return

            data = []
            while query.next():
                record_id = query.value(0)
                oid = query.value(1)
                name = query.value(2)
                contact = query.value(3)
                detected_dt = query.value(4)
                photo_blob = query.value(5)
                zone = query.value(6)
                status = query.value(7)
                data.append((record_id, oid, name, contact, detected_dt, zone, status))

            # Close the database connection
            db.close()

            if not data:
                print("No data found within the specified date range.")
                return

            # Fetch data and write to CSV
            with open(csv_filename, "w", newline="") as csv_file:
                csv_writer = csv.writer(csv_file)

                # Write header
                field_names = ["RecordID", "OID", "Name", "Contact", "DetectedDT", "Zone", "Status"]
                csv_writer.writerow(field_names)

                # Write data
                for row in data:
                    csv_writer.writerow(row)

            print(f"Data exported to {csv_filename} successfully.")
            msg_box = QMessageBox()
            msg_box.setIcon(QMessageBox.Information)
            msg_box.setWindowTitle("Export Successful")
            msg_box.setText(f"Data exported to {csv_filename} successfully.")
            msg_box.exec_()

        except Exception as e:
            print("Error retrieving and exporting data:", e)


if __name__ == "__main__":
    # Create the QApplication instance
    app = QApplication(sys.argv)

    # Create the FVWindow instance
    reportWindow = MainReport_Window()

    # Show the main window directly
    reportWindow.show()

    # Start the application event loop
    sys.exit(app.exec_())
