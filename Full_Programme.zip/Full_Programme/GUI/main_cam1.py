import sys
import re
import cv2
from UI_cam1 import Ui_FVWindow
from PySide2.QtGui import QPixmap, QImage, QFontMetrics, QFont, QColor
from PySide2.QtWidgets import QApplication, QMainWindow, QLabel, QFrame, QMessageBox, QAction, QListWidgetItem, \
    QListWidget
from PySide2.QtCore import Qt, QTimer, QRect, QCoreApplication
from PySide2.QtSql import QSqlDatabase, QSqlQuery
from datetime import datetime
import sqlite3

from test_main_occupants import MainOccupantsWindow
from main_occupant_detail import MainOccupants_DetailWindow

from main_faceRecogntion import Facerec

sfr = Facerec()
sfr.load_encoding_images("images/")



# class LoginWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()
#
#         # Create an instance of the Ui_MainWindow class
#         self.ui = Ui_MainWindow()
#
#         # Set up the user interface
#         self.ui.setupUi(self)
#
#         # Connect the login button to the login function
#         self.ui.pushButton.clicked.connect(self.login)
#
#
#
#         # Set the fixed size of the main window
#         self.setFixedSize(self.size())
#
#     def login(self):
#         username = self.ui.textEdit.toPlainText()
#         password = self.ui.textEdit_4.text()
#         print(username)
#         print(password)
#
#         # Check if the username and password are valid
#         if username == "aaa" and password == "aaa":
#             QMessageBox.information(self, "Login Successful", "Welcome, admin!")
#             self.open_fv_window()
#         else:
#             QMessageBox.warning(self, "Login Failed", "Invalid username or password. Please try again.")
#
#     def open_fv_window(self):
#         # Create the FVWindow instance
#         self.fvWindow = FVWindow()
#
#         # Hide the LoginWindow
#         self.hide()
#
#         # Show the FVWindow
#         self.fvWindow.show()
#
#     def closeEvent(self, event):
#         # Close the FVWindow if it is open
#         if hasattr(self, 'fvWindow'):
#             self.fvWindow.close()
#
#         event.accept()


class FVWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Create an instance of the Ui_FVWindow class
        self.ui = Ui_FVWindow()

        # Set up the user interface
        # custom_color = QColor(176, 224, 230)
        # self.setStyleSheet(f"background-color: {custom_color.name()};")

        self.ui.setupUi(self)

        self.detail_window = None

        # Set the fixed size of the FVWindow
        self.setFixedSize(self.size())

        # Add any additional setup for the FVWindow
        self.create_detected_occupants_table()


        # Open the camera
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1201)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 550)

        # self.cap2 = cv2.VideoCapture(1)
        # self.cap2.set(cv2.CAP_PROP_FRAME_WIDTH, 1201)
        # self.cap2.set(cv2.CAP_PROP_FRAME_HEIGHT, 550)

        # Create a QLabel widget to display the image
        self.image_label = QLabel(self.ui.frame)
        self.image_label.setGeometry(QRect(0, 0, 1201, 550))
        self.image_label.setScaledContents(True)

        self.photo_label = QLabel(self.ui.frame_2)
        self.photo_label.setScaledContents(True)
        self.photo_label.setGeometry(QRect(5, 0, 230, 220))

        self.listWidget = QListWidget(self.ui.listWidget)
        self.listWidget.setGeometry(0,0,275,1500)
        self.listWidget.setAutoScroll(True)

        self.listWidget.itemClicked.connect(self.click_list_item)

        self.retrieve_detected_occupants()


        # Start the timer to update the frame
        # self.timer = QTimer()
        # self.timer.timeout.connect(self.update_frame)
        # self.timer.timeout.connect(self.update_list_background)
        # self.timer.start(30)  # Update every 30 milliseconds

        text_browser_height = 35
        self.ui.textBrowser_13.setFixedHeight(text_browser_height)
        self.ui.textBrowser_12.setFixedHeight(text_browser_height)
        self.ui.textBrowser_14.setFixedHeight(text_browser_height)

        self.ui.plainTextEdit.setFixedHeight(text_browser_height)

        # Set the font size of the textBrowser widgets
        font_size = 12
        font = QFont()
        font.setPointSize(font_size)
        self.ui.textBrowser_12.setFont(font)
        self.ui.textBrowser_13.setFont(font)
        self.ui.textBrowser_14.setFont(font)


        # Start the timer to update the current time
        self.time_timer = QTimer()
        self.time_timer.timeout.connect(self.update_frame)
        #self.time_timer.timeout.connect(self.update_list_background)
        self.time_timer.timeout.connect(self.update_datetime)
        self.time_timer.timeout.connect(self.count_occ_in_building)
        self.time_timer.start(1000)  # Update every 1 second

        self.ui.pushButton.clicked.connect(self.filter_list_widget)

        # Uncomment the following lines to connect the "Occupants" menu item

        # self.actionOccupants_Details = QAction(self)
        # self.actionOccupants_Details.setObjectName(u"actionOccupants_Details")
        # self.ui.menuOccupants.addAction(self.actionOccupants_Details)
        # self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))

        # Connect the actionOccupants_Details.triggered signal to open the MainOccupantsWindow

#        self.actionOccupants_Details.triggered.connect(self.openOccupantsWindow)

    def create_detected_occupants_table(self):
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to create the "Detected_Occ" table
        query = QSqlQuery()
        query.prepare(
            '''CREATE TABLE IF NOT EXISTS Detected_Occ(
                     RecordID INTEGER PRIMARY KEY AUTOINCREMENT,
                     OID INTEGER,
                     Name VARCHAR(255),
                     Contact CHAR(11),
                     DetectedDT DATETIME,
                     Photo BLOB,
                     Zone CHAR(10),
                     Status CHAR(5)
                     )
                     ''')

        if not query.exec_():
            print("Failed to create the Detected_Occ table.")
            db.close()
            return

        # Close the database connection
        db.close()

    # def create_det_available_table(self):
    #     # Connect to the database
    #     db = QSqlDatabase.addDatabase("QSQLITE")
    #     db.setDatabaseName("Occupants.db")
    #     if not db.open():
    #         print("Failed to connect to the database.")
    #         return
    #
    #     # Execute a query to create the "Detected_Occ" table
    #     query = QSqlQuery()
    #     query.prepare(
    #         '''CREATE TABLE IF NOT EXISTS Det_Available(
    #                  Trans_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    #                  OID INTEGER,
    #                  DetectedDT DATETIME,
    #                  Zone CHAR(10),
    #                  Status CHAR(5)
    #                  )
    #                  ''')
    #
    #     if not query.exec_():
    #         print("Failed to create the Det_Available table.")
    #         db.close()
    #         return
    #
    #     # Close the database connection
    #     db.close()

    def update_status_in_occ_status(self, detected_name, new_status, zone):
        try:
            # Connect to the database
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("Occupants.db")
            if not db.open():
                print("Failed to connect to the database.")
                return

            # Create a QSqlQuery object
            query = QSqlQuery()

            # Retrieve the current status before updating
            query.prepare("SELECT Status FROM occ_status WHERE Name = ?")
            query.addBindValue(detected_name)
            if query.exec_() and query.next():
                current_status = query.value(0)
            else:
                print(f"Failed to retrieve current status for '{detected_name}' from 'occ_status' table.")
                db.close()
                return

            # Only update if the new status is different
            if current_status != new_status:
                current_datetime = datetime.now().strftime("%m/%d/%Y %H:%M:%S")

                # Update 'occ_status' table
                query.prepare("UPDATE occ_status SET Status = ?, LastDeteced = ?, Zone = ? WHERE Name = ?")
                query.addBindValue(new_status)
                query.addBindValue(current_datetime)
                query.addBindValue(zone)
                query.addBindValue(detected_name)

                if query.exec_():
                    print(f"Updated 'Status' for '{detected_name}' to '{new_status}' in 'occ_status' table.")
                else:
                    print(f"Failed to update 'Status' for '{detected_name}' in 'occ_status' table.")

                # Insert into 'Detected_Trans' table
                query.prepare("INSERT INTO Detected_Trans (OID, Name, LastDetectedDT, Zone, Status) "
                              "SELECT OID, Name, LastDeteced, Zone, Status FROM occ_status WHERE Name = ?")
                query.addBindValue(detected_name)

                if query.exec_():
                    print(f"Inserted into 'Detected_Trans' table: {detected_name}, {current_datetime}, {new_status}")
                else:
                    print(f"Failed to insert into 'Detected_Trans' table for '{detected_name}'.")

            else:
                print(f"No change in status for '{detected_name}'.")

            # Close the database connection
            db.close()

        except Exception as e:
            print("Error updating status:", e)

    def count_occ_in_building(self):
        try:
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("Occupants.db")
            if not db.open():
                print("Failed to connect to the database.")
                return

            query = QSqlQuery()
            if query.exec_("SELECT COUNT(*) FROM occ_status WHERE Status = 'IN'"):
                if query.next():
                    in_count = query.value(0)
                    text = f"Head Count: {in_count}"
                    self.ui.textBrowser_14.setPlainText(text)
                else:
                    print("Failed to retrieve count from 'occ_status' table.")
            else:
                print("Failed to execute query.")

            db.close()

        except Exception as e:
            print("Error:", e)

    def update_frame(self):
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        ret, frame = self.cap.read()
        if ret:
            gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)

            # Detect faces
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)

            face_locations, face_names = sfr.detect_known_faces(frame)

            # #add new record in Detected_Occ
            # db = QSqlDatabase.addDatabase("QSQLITE")
            # db.setDatabaseName("Occupants.db")
            # if not db.open():
            #     print("Failed to connect to database.")
            #     return

            # Process each detected face
            for (x, y, w, h), face_name in zip(face_locations, face_names):

                is_blacklisted = self.check_blacklist(face_name)

                for face_loc, name in zip(face_locations, face_names):
                    # top=y1 left=x1 bottom=y2 right=x2
                    y1, x1, y2, x2 = face_loc[0], face_loc[1], face_loc[2], face_loc[3]

                    cv2.putText(frame, name, (x1, y1 - 10), cv2.FONT_HERSHEY_DUPLEX, 1, (0, 0, 0), 2)
                    if is_blacklisted:
                        color = (0, 0, 200)

                    elif "vip" in name:
                        color = (200, 0, 0)
                    else:
                        color = (0, 200, 0)

                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 4)

                # Retrieve data from the database based on the recognized face name
                data = retrieve_data_from_database(face_name)

                # Display the retrieved data
                self.ui.textBrowser_7.setText(str(data.get("ID", "")))
                self.ui.textBrowser_4.setText(data.get("NAME"))
                #self.ui.textBrowser_7.setText("Contact: " + data.get("CONTACT", ""))
                self.ui.textBrowser_6.setText(data.get("COMPANY"))

                current_datetime = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
                self.ui.textBrowser_10.setText(current_datetime)

                photo_data = data.get("PHOTO", None)

                #add new record in Detected_Occ
                db = QSqlDatabase.addDatabase("QSQLITE")
                db.setDatabaseName("Occupants.db")
                if not db.open():
                    print("Failed to connect to database.")
                    return

                query = QSqlQuery()
                query.prepare("INSERT INTO Detected_Occ (OID, Name, Contact, DetectedDT, Photo, Zone, Status) VALUES(?, ?, ?, ?, ?, ?, ?)")
                query.addBindValue(data.get("ID", ""))
                query.addBindValue(data.get("NAME"))
                query.addBindValue(data.get("CONTACT", ""))
                query.addBindValue(current_datetime)
                query.addBindValue(data.get("PHOTO", None))
                query.addBindValue(data.get("ZONE", "LV01_Z01"))
                query.addBindValue(data.get("STATUS", "IN"))
                new_zone = data.get("ZONE", "LV01_Z01")

                oid = data.get("ID", "")
                detected_dt = current_datetime
                contact = data.get("CONTACT", "")
                status = data.get("STATUS", "IN")

                if not query.exec_():
                    print("Failed to insert record into Detected_Occ:", query.lastError().text())

                self.update_status_in_occ_status(name, "IN",new_zone)

                if photo_data is not None:
                    # Create a QImage from the photo data
                    image = QImage.fromData(photo_data)

                    if not image.isNull():
                        # Scale the image to fit the label size
                        scaled_image = image.scaled(self.photo_label.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                                    Qt.SmoothTransformation)
                        # Create a QPixmap from the scaled image
                        pixmap = QPixmap.fromImage(scaled_image)
                        self.photo_label.setPixmap(pixmap)

                # Draw a rectangle around the face
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                datetime_obj = datetime.strptime(detected_dt, "%m/%d/%Y %H:%M:%S")
                detected_dt_formatted = datetime_obj.strftime("%d-%m-%Y %H:%M:%S")

                item_text = f"OID: {oid}\nName: {name}\nContact: {contact}\nDetected Time: {detected_dt_formatted}\nStatus: {status}\n"

                item = QListWidgetItem(item_text)

                is_blacklisted = self.check_blacklist(name)

                if is_blacklisted:
                    item.setBackground(QColor(255, 200, 200))
                else:
                    item.setBackground(QColor(255, 255, 255))

                self.listWidget.insertItem(0, item)

                db.close()

                # query = QSqlQuery()
                # query.prepare(
                #     "INSERT INTO Detected_Occ (OID, Name, Contact, DetectedDT, Photo) VALUES(?, ?, ?, ?, ?)"
                # )
                # query.addBindValue(data.get("ID", ""))
                # query.addBindValue(data.get("NAME"))
                # query.addBindValue(data.get("CONTACT", ""))
                # query.addBindValue(current_datetime)
                # query.addBindValue(data.get("PHOTO", ""))
                #
                # db.close()

            # Convert the frame from BGR to RGB and display it
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image = QImage(frame_rgb.data, frame_rgb.shape[1], frame_rgb.shape[0], QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(image)
            self.image_label.setPixmap(pixmap)

            #self.retrieve_available_occ()
            #self.retrieve_detected_occupants()
            self.filter_list_widget()

        # Close the database connection

    # def update_frame2(self):
    #     face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    #     ret, frame = self.cap2.read()
    #     if ret:
    #         gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    #
    #         faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)
    #
    #         face_locations, face_names = sfr.detect_known_faces(frame)
    #
    #         for (x, y, w, h), face_name in zip(face_locations, face_names):
    #
    #             # Retrieve data from the database based on the recognized face name
    #             data = retrieve_data_from_database(face_name)
    #
    #             # Display the retrieved data
    #             self.ui.textBrowser_7.setText(str(data.get("ID", "")))
    #             self.ui.textBrowser_4.setText(data.get("NAME"))
    #             #self.ui.textBrowser_7.setText("Contact: " + data.get("CONTACT", ""))
    #             self.ui.textBrowser_6.setText(data.get("COMPANY"))
    #
    #             current_datetime = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    #             self.ui.textBrowser_10.setText(current_datetime)
    #
    #             photo_data = data.get("PHOTO", None)
    #
    #             #add new record in Detected_Occ
    #             db = QSqlDatabase.addDatabase("QSQLITE")
    #             db.setDatabaseName("Occupants.db")
    #             if not db.open():
    #                 print("Failed to connect to database.")
    #                 return
    #
    #             query = QSqlQuery()
    #             query.prepare("INSERT INTO Detected_Occ (OID, Name, Contact, DetectedDT, Photo, Zone, Status) VALUES(?, ?, ?, ?, ?, ?, ?)")
    #             query.addBindValue(data.get("ID", ""))
    #             query.addBindValue(data.get("NAME"))
    #             query.addBindValue(data.get("CONTACT", ""))
    #             query.addBindValue(current_datetime)
    #             query.addBindValue(data.get("PHOTO", None))
    #             query.addBindValue(data.get("ZONE", "LV01_Z04"))
    #             query.addBindValue(data.get("STATUS", "OUT"))
    #             new_zone = data.get("ZONE", "LV01_Z04")
    #
    #             if not query.exec_():
    #                 print("Failed to insert record into Detected_Occ:", query.lastError().text())
    #
    #             self.update_status_in_occ_status(face_name, "OUT", new_zone)
    #
    #             # if photo_data is not None:
    #             #     # Create a QImage from the photo data
    #             #     image = QImage.fromData(photo_data)
    #             #
    #             #     if not image.isNull():
    #             #         # Scale the image to fit the label size
    #             #         scaled_image = image.scaled(self.photo_label.size(), Qt.AspectRatioMode.KeepAspectRatio,
    #             #                                     Qt.SmoothTransformation)
    #             #         # Create a QPixmap from the scaled image
    #             #         pixmap = QPixmap.fromImage(scaled_image)
    #             #         self.photo_label.setPixmap(pixmap)
    #             #
    #             # # Draw a rectangle around the face
    #             # cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
    #
    #             # query = QSqlQuery()
    #             # query.prepare(
    #             #     "INSERT INTO Detected_Occ (OID, Name, Contact, DetectedDT, Photo) VALUES(?, ?, ?, ?, ?)"
    #             # )
    #             # query.addBindValue(data.get("ID", ""))
    #             # query.addBindValue(data.get("NAME"))
    #             # query.addBindValue(data.get("CONTACT", ""))
    #             # query.addBindValue(current_datetime)
    #             # query.addBindValue(data.get("PHOTO", ""))
    #             #
    #             # db.close()
    #
    #     # Close the database connection

    def update_datetime(self):
        # Update current date in textBrowser_13
        current_date = datetime.now().strftime("%d-%m-%Y")  # Changed format here
        self.ui.textBrowser_13.setText(current_date)

        # Update current time in textBrowser_12
        current_time = datetime.now().strftime("%H:%M:%S")
        self.ui.textBrowser_12.setText(current_time)

        # Update current date and time in textBrowser_10
        #current_datetime = datetime.now().strftime("%m/%d/%Y %H:%M:%S")

    def openOccupantsWindow(self):
        # Create the MainOccupantsWindow instance
        self.occupantsWindow = MainOccupantsWindow()

        # Hide the FVWindow
        self.hide()

        # Show the MainOccupantsWindow
        self.occupantsWindow.show()

    def retrieve_detected_occupants(self):
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to fetch records from Detected_Occ table
        query = QSqlQuery()
        #query.prepare("SELECT * FROM Detected_Occ ORDER BY detected_dt DESC LIMIT 100")
        query.prepare("SELECT * FROM Detected_Occ")
        if not query.exec_():
            print("Failed to fetch records from Detected_Occ table.")
            db.close()
            return

        # Clear the list widget
        self.listWidget.clear()

        # Populate the list widget with the retrieved data
        while query.next():
            oid = query.value(1)
            name = query.value(2)
            contact = query.value(3)
            detected_dt = query.value(4)
            status = query.value(7)
            item_OID = oid


            datetime_obj = datetime.strptime(detected_dt, "%m/%d/%Y %H:%M:%S")
            detected_dt_formatted = datetime_obj.strftime("%d-%m-%Y %H:%M:%S")

            item_text = f"OID: {oid}\nName: {name}\nContact: {contact}\nDetected Time: {detected_dt_formatted}\nStatus: {status}\n"

            item = QListWidgetItem(item_text)

            self.listWidget.insertItem(0, item)

        # Close the database connection
        db.close()

    def update_list_background(self):
        for row in range(self.listWidget.count()):
            item = self.listWidget.item(row)
            item_text = item.text()

            lines = item_text.split("\n")
            name_line = next(line for line in lines if "Name:" in line)
            name = name_line.split(":")[1].strip()

            is_blacklisted = self.check_blacklist(name)

            if is_blacklisted:
                item.setBackground(QColor(255, 200, 200))
            else:
                item.setBackground(QColor(255, 255, 255))

    def click_list_item(self, item):
        # Access the clicked item
        clickedItem = item.text()

        print(clickedItem)
        match = re.search(r"\b\d+\b", clickedItem)
        if match:
            clicked_OID = match.group()
            print(clicked_OID)

        # If the detail window doesn't exist or has been closed, create a new instance
        if not self.detail_window or not self.detail_window.isVisible():
            self.detail_window = MainOccupants_DetailWindow()

        # Set the clicked item name in the detail window
        self.detail_window.set_clicked_item(clickedItem, clicked_OID)

        # Show the detail window
        self.detail_window.show()

    def filter_list_widget(self):
        filter_text = self.ui.plainTextEdit.toPlainText().strip().lower()

        for index in range(self.listWidget.count()):
            item = self.listWidget.item(index)
            item_text = item.text().lower()
            if filter_text in item_text:
                item.setHidden(False)
            else:
                item.setHidden(True)

    def check_blacklist(self, facename):
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")

        if not db.open():
            print("Failed to connect to the database.")
            return False

        query = QSqlQuery()
        query.prepare("SELECT COUNT(*) FROM Blacklist WHERE NAME = :name")
        query.bindValue(":name", facename)

        if not query.exec_():
            print("Failed to check if occupant is in Blacklist.")
            db.close()
            return False

        query.next()
        count = query.value(0)

        db.close()
        return count > 0

def retrieve_data_from_database(face_name):
    try:
        # Connect to the database
        conn = sqlite3.connect("Occupants.db")
        c = conn.cursor()

        # Execute a SELECT query to retrieve the data based on the face name
        c.execute("SELECT * FROM Occupants WHERE Name = ?", (face_name,))
        data = c.fetchone()

        # Close the database connection
        conn.close()

        # Return the retrieved data as a dictionary
        if data:
            return {
                "ID": data[0],
                "NAME": data[1],
                "CONTACT": data[2],
                "COMPANY": data[3],
                "DATE/TIME": data[4],
                "PHOTO":data[8]
            }

    except sqlite3.Error as e:
        print("Error retrieving data from database:", e)

    return {}

if __name__ == "__main__":
    # Create the QApplication instance
    app = QApplication(sys.argv)
    # Create the FVWindow instance
    fvWindow = FVWindow()
    # Show the main window directly
    fvWindow.show()
    # Start the application event loop
    sys.exit(app.exec_())


