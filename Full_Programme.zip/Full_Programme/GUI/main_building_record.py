import sys
from PySide2.QtGui import QFont
from PySide2.QtCore import Qt, QDateTime, QTimer, QDate
from PySide2.QtSql import QSqlDatabase, QSqlQuery
from PySide2.QtWidgets import QApplication, QMainWindow, QFormLayout, QWidget, QHBoxLayout, QTableWidgetItem, \
    QHeaderView, QTableWidget, QStyledItemDelegate
from UI_building_record import Ui_BuildingrecordWindow
from main_occupant_detail import MainOccupants_DetailWindow as MOD
from main_building_summarized import UI_BuildingSum_Window as SUM

xml_ui = '''
<ui version="4.0">
    <class>BuildingrecordWindow</class>
    <widget class="QMainWindow" name="BuildingrecordWindow">
        <property name="geometry">
            <rect>
                <x>0</x>
                <y>0</y>
                <width>1425</width>
                <height>837</height>
            </rect>
        </property>
        <property name="windowTitle">
            <string>MainWindow</string>
        </property>
        <widget class="QWidget" name="centralwidget">
            <widget class="QTextBrowser" name="textBrowser">
                <property name="geometry">
                    <rect>
                        <x>0</x>
                        <y>0</y>
                        <width>261</width>
                        <height>41</height>
                    </rect>
                </property>
                <property name="verticalScrollBarPolicy">
                    <enum>Qt::ScrollBarAlwaysOff</enum>
                </property>
            </widget>
            <!-- Rest of the UI definition goes here -->
        </widget>
    </widget>
</ui>
'''

class BuildingRecord_Window(QMainWindow, Ui_BuildingrecordWindow):
    def __init__(self):
        super(BuildingRecord_Window, self).__init__()

        self.setupUi(self)

        self.setFixedSize(self.size())
        self.adjustTableSize()
        self.tableWidget.horizontalHeader().setStretchLastSection(True)
        self.tableWidget.setEditTriggers(QTableWidget.NoEditTriggers)

        default_date = QDate()
        self.date_edit.setDate(default_date)



        self.formLayout.setRowWrapPolicy(QFormLayout.WrapLongRows)
        item_height = 35
        for i in range(self.formLayout.rowCount()):
            layout_item = self.formLayout.itemAt(i, QFormLayout.FieldRole)
            if layout_item and layout_item.widget():
                layout_item.widget().setFixedHeight(item_height)

        self.load_data_from_database()

        # self.update_timer = QTimer(self)
        # self.update_timer.timeout.connect(self.load_data_from_database)
        # self.update_timer.start(5000)  # 10 seconds

        self.btn_filter.clicked.connect(self.apply_filters)
        self.btn_searchID.clicked.connect(self.open_occupant_detail_window)
        self.btn_summarize.clicked.connect(self.open_building_summarized_window)

        # self.combo_sort.currentIndexChanged.connect(self.sort_table)
        #
        # self.combo_status.currentIndexChanged.connect(self.filter_table_by_status)
        #
        # self.combo_entrance.currentIndexChanged.connect(self.filter_table_by_entrance)
        #
        # self.date_edit.dateChanged.connect(self.filter_table_by_date)
        #
        # self.load_data_from_database()
        #
        # self.btn_filter.clicked.connect(self.sort_table())

        # self.update_timer = QTimer(self)
        # self.update_timer.timeout.connect(self.load_data_from_database)
        # self.update_timer.start(10000)  # 10 seconds

    def load_data_from_database(self):
        # Establish the connection to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Error: Failed to connect to the database.")
            return

        # Retrieve data from Detected_Occ and Occupants tables
        query = QSqlQuery()
        query.prepare('''SELECT Detected_Occ.OID, Detected_Occ.DetectedDT, Detected_Occ.Zone, Detected_Occ.Status, Occupants.Name, Occupants.Company 
                         FROM Detected_Occ
                         LEFT JOIN Occupants ON Detected_Occ.OID = Occupants.OID''')

        if not query.exec_():
            print("Error: Failed to execute the query.")
            db.close()
            return

        # Clear the existing table contents
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(6)

        # Populate the table with data
        row_index = 0
        while query.next():
            oid = query.value(0)
            detected_dt = query.value(1)
            name = query.value(4)
            company = query.value(5)
            zone = query.value(2)
            status = query.value(3)

            detected_dt = QDateTime.fromString(detected_dt, "MM/dd/yyyy HH:mm:ss")
            detected_dt_formatted = detected_dt.toString("dd-MM-yyyy HH:mm:ss")

            # Insert the data into the table
            # self.tableWidget.insertRow(row_index)
            # self.tableWidget.setItem(row_index, 0, QTableWidgetItem(str(oid)))
            item = QTableWidgetItem(str(oid))
            self.tableWidget.insertRow(row_index)
            self.tableWidget.setItem(row_index, 0, item)

            self.tableWidget.setItem(row_index, 1, QTableWidgetItem(str(name)))
            self.tableWidget.setItem(row_index, 2, QTableWidgetItem(str(company)))
            self.tableWidget.setItem(row_index, 3, QTableWidgetItem(str(detected_dt_formatted)))
            self.tableWidget.setItem(row_index, 4, QTableWidgetItem(str(zone)))
            self.tableWidget.setItem(row_index, 5, QTableWidgetItem(str(status)))
            row_index += 1

        # Close the database connection
        db.close()

    # def adjustTableSize(self):
    #
    #     # Set the column width to expand to fit the contents
    #     for col in range(self.tableWidget.columnCount()):
    #         self.tableWidget.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
    #
    #     # Set the alignment of all cells to center
    #     for row in range(self.tableWidget.rowCount()):
    #         for col in range(self.tableWidget.columnCount()):
    #             item = self.tableWidget.item(row, col)
    #             if item is not None:
    #                 item.setTextAlignment(Qt.AlignCenter)

    def adjustTableSize(self):
        # Set the column width to expand to fit the contents
        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)

        # Set fixed sizes for specific columns
        header = self.tableWidget.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        header.resizeSection(0, 150)

        header.setSectionResizeMode(1, QHeaderView.Fixed)
        header.resizeSection(1, 300)

        header.setSectionResizeMode(2, QHeaderView.Fixed)
        header.resizeSection(2, 170)

        header.setSectionResizeMode(3, QHeaderView.Fixed)
        header.resizeSection(3, 280)

        header.setSectionResizeMode(4, QHeaderView.Fixed)
        header.resizeSection(4, 190)

        header.setSectionResizeMode(5, QHeaderView.Fixed)
        header.resizeSection(5, 190)

        # font = QFont("Arial", 15)
        # Set the alignment of all cells to center
        for row in range(self.tableWidget.rowCount()):
            for col in range(self.tableWidget.columnCount()):
                item = self.tableWidget.item(row, col)
                if item is not None:
                    item.setTextAlignment(Qt.AlignCenter)

        delegate = FontSizeDelegate(self.tableWidget)
        self.tableWidget.setItemDelegate(delegate)

        font = QFont("Arial", 12)  # Adjust the font size as needed
        self.tableWidget.horizontalHeader().setFont(font)
        self.tableWidget.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)

    def sort_table(self,sorting_option):

        # Sort the data in the table based on the selected option
        if sorting_option == "Occupant ID":
            self.sort_table_by_occupant_id()
            #self.tableWidget.sortItems(0, Qt.AscendingOrder)
        elif sorting_option == "Name":
            self.tableWidget.sortItems(1, Qt.AscendingOrder)
        elif sorting_option == "Company":
            self.tableWidget.sortItems(2, Qt.AscendingOrder)
        elif sorting_option == "Date Time":
            self.tableWidget.sortItems(3, Qt.AscendingOrder)
        elif sorting_option == "Entrance":
            self.tableWidget.sortItems(4, Qt.AscendingOrder)
        elif sorting_option == "Status":
            self.tableWidget.sortItems(5, Qt.AscendingOrder)

    def sort_table_by_occupant_id(self):
        rows = []
        for row in range(self.tableWidget.rowCount()):
            item = self.tableWidget.item(row, 0)
            oid_text = item.text()
            numeric_oid = int(oid_text) if oid_text.isdigit() else 0
            rows.append((numeric_oid, [self.tableWidget.item(row, col).text() for col in range(self.tableWidget.columnCount())]))

        rows.sort(key=lambda x: x[0])
        for row, (value, row_data) in enumerate(rows):
            for col, data in enumerate(row_data):
                self.tableWidget.setItem(row, col, QTableWidgetItem(data))

    # def numeric_sort_key(self, item):
    #     try:
    #         return int(item.text())
    #     except ValueError:
    #         return float('inf')

    def filter_table_by_floor(self):
        selected_floor = self.combo_floor.currentText().strip()

        # Check if the selected entrance is empty
        if not selected_floor:
            # If empty, show all rows in the table and return
            for row in range(self.tableWidget.rowCount()):
                self.tableWidget.showRow(row)
            return

        # Create a mapping from entrance names to their corresponding codes
        entrance_mapping = {
            "Floor 1": "LV01",
            "Floor 2": "LV02",
            "Floor 3": "LV03",
            "Floor 4": "LV04",
        }
        # Reload the data from the database
        self.load_data_from_database()

        # Get the corresponding code from the mapping
        floor_code = entrance_mapping.get(selected_floor)

        # Apply the filter and populate the table with filtered data
        for row in range(self.tableWidget.rowCount()):
            entrance_item = self.tableWidget.item(row, 4)

            if floor_code and floor_code.lower() not in entrance_item.text().lower():
                self.tableWidget.hideRow(row)
            else:
                self.tableWidget.showRow(row)

    def filter_table_by_entrance(self):
        selected_entrance = self.combo_entrance.currentText().strip()

        # Check if the selected entrance is empty
        if not selected_entrance:
            # If empty, show all rows in the table and return
            for row in range(self.tableWidget.rowCount()):
                self.tableWidget.showRow(row)
            return

        # Create a mapping from entrance names to their corresponding codes
        entrance_mapping = {
            "Zone 1": "Z01",
            "Zone 2": "Z02",
            "Zone 3": "Z03",
            "Zone 4": "Z04",
        }

        # Reload the data from the database
        self.load_data_from_database()

        # Get the corresponding code from the mapping
        entrance_code = entrance_mapping.get(selected_entrance)

        # Apply the filter and populate the table with filtered data
        for row in range(self.tableWidget.rowCount()):
            entrance_item = self.tableWidget.item(row, 4)

            if entrance_code and entrance_code.lower() not in entrance_item.text().lower():
                self.tableWidget.hideRow(row)
            else:
                self.tableWidget.showRow(row)

    def filter_table_by_date(self):
        selected_date = self.date_edit.date().toPython()
        formatted_date = selected_date.strftime("%d-%m-%Y")
        print("now: " + str(formatted_date))

        # Reload the data from the database
        self.load_data_from_database()

        if formatted_date is None:
            # If no date is selected, show all rows in the table and return
            for row in range(self.tableWidget.rowCount()):
                self.tableWidget.showRow(row)
            return

        # Apply the filter and populate the table with filtered data
        for row in range(self.tableWidget.rowCount()):
            item_date_str = self.tableWidget.item(row, 3).text()

            if formatted_date in item_date_str:
                self.tableWidget.showRow(row)
            else:
                self.tableWidget.hideRow(row)

    def filter_table_by_status(self):
        selected_status = self.combo_status.currentText()

        # Reload the data from the database
        self.load_data_from_database()

        if selected_status.strip() == "":
            # If empty, show all rows in the table and return
            for row in range(self.tableWidget.rowCount()):
                self.tableWidget.showRow(row)
            return

        # Reload the data from the database
        self.load_data_from_database()

        # Apply the filter and populate the table with filtered data
        for row in range(self.tableWidget.rowCount()):
            status_item = self.tableWidget.item(row, 5)
            if status_item.text() != selected_status:
                self.tableWidget.hideRow(row)
            else:
                self.tableWidget.showRow(row)

    def apply_filters(self):
        # self.filter_table_by_floor()
        # self.filter_table_by_entrance()
        # self.filter_table_by_date()
        # self.filter_table_by_status()
        # self.sort_table()
        self.load_data_from_database()

        selected_entrance = self.combo_entrance.currentText().strip()
        selected_status = self.combo_status.currentText().strip()
        selected_date = self.date_edit.date().toPython()
        formatted_date = selected_date.strftime("%d-%m-%Y")
        selected_floor = self.combo_floor.currentText().strip()
        selected_sort = self.combo_sort.currentText().strip()

        # Reload the data from the database
        self.load_data_from_database()

        for row in range(self.tableWidget.rowCount()):
            item_entrance = self.tableWidget.item(row, 4)
            item_status = self.tableWidget.item(row, 5)
            item_date_str = self.tableWidget.item(row, 3).text()
            item_level = self.tableWidget.item(row, 2)
            sorting_option = self.combo_sort.currentText()

            # Filter by entrance
            if selected_entrance and selected_entrance != " ":
                ent = "Z0" + selected_entrance[-1]
                if ent not in item_entrance.text():
                    self.tableWidget.hideRow(row)
                    continue

            # Filter by status
            if selected_status and selected_status != " ":
                if selected_status != item_status.text():
                    self.tableWidget.hideRow(row)
                    continue

            # Filter by date
            if selected_date:
                if formatted_date not in item_date_str:
                    self.tableWidget.hideRow(row)
                    continue

            # Filter by level
            if selected_floor and selected_floor != " ":
                entrance_mapping = {
                    "Floor 1": "LV01",
                    "Floor 2": "LV02",
                    "Floor 3": "LV03",
                    "Floor 4": "LV04",
                }
                floor_code = entrance_mapping.get(selected_floor)
                if floor_code and floor_code.lower() not in item_entrance.text().lower():
                    self.tableWidget.hideRow(row)
                    continue

            self.tableWidget.showRow(row)

        # Sort the table by occupant_id (assuming it is in column 0)
        self.sort_table(sorting_option)

    def open_occupant_detail_window(self):
        self.occupant_detail_window = MOD()
        self.occupant_detail_window.show()

    def open_building_summarized_window(self):
        self.building_summarized_window = SUM()
        self.building_summarized_window.show()
class FontSizeDelegate(QStyledItemDelegate):
    def __init__(self, parent=None):
        super(FontSizeDelegate, self).__init__(parent)
        self.font = QFont("Arial", 12)

    def paint(self, painter, option, index):
        option.font = self.font
        option.displayAlignment = Qt.AlignCenter  # Align content to center
        super(FontSizeDelegate, self).paint(painter, option, index)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BuildingRecord_Window()
    window.show()
    sys.exit(app.exec_())
