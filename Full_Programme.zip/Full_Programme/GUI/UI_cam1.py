
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_FVWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1468, 837)
        self.actionMain = QAction(MainWindow)
        self.actionMain.setObjectName(u"actionMain")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")

        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 1201, 561))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.verticalLayoutWidget = QWidget(self.centralwidget)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(1200, 0, 274, 800))
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.textBrowser_13 = QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser_13.setObjectName(u"textBrowser_13")

        self.verticalLayout.addWidget(self.textBrowser_13)

        self.textBrowser_12 = QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser_12.setObjectName(u"textBrowser_12")

        self.verticalLayout.addWidget(self.textBrowser_12)

        self.textBrowser_14 = QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser_14.setObjectName(u"textBrowser_14")

        self.verticalLayout.addWidget(self.textBrowser_14)

        self.plainTextEdit = QPlainTextEdit(self.verticalLayoutWidget)
        self.plainTextEdit.setObjectName(u"plainTextEdit")

        self.verticalLayout.addWidget(self.plainTextEdit)

        self.pushButton = QPushButton(self.verticalLayoutWidget)
        self.pushButton.setObjectName(u"pushButton")

        self.verticalLayout.addWidget(self.pushButton)

        self.listWidget = QListWidget(self.verticalLayoutWidget)
        QListWidgetItem(self.listWidget)
        QListWidgetItem(self.listWidget)
        QListWidgetItem(self.listWidget)
        QListWidgetItem(self.listWidget)
        self.listWidget.setObjectName(u"listWidget")

        self.verticalLayout.addWidget(self.listWidget)

        self.frame_2 = QFrame(self.centralwidget)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setGeometry(QRect(0, 560, 231, 221))
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.formLayoutWidget = QWidget(self.centralwidget)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(240, 560, 961, 201))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.textBrowser_5 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_5.setObjectName(u"textBrowser_5")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.textBrowser_5)

        self.textBrowser_7 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_7.setObjectName(u"update_OID")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.textBrowser_7)

        self.textBrowser_8 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_8.setObjectName(u"textBrowser_8")

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.textBrowser_8)

        self.textBrowser_6 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_6.setObjectName(u"update_company")

        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.textBrowser_6)

        self.textBrowser = QTextBrowser(self.formLayoutWidget)
        self.textBrowser.setObjectName(u"textBrowser")

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.textBrowser)

        self.textBrowser_4 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_4.setObjectName(u"update_name")

        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.textBrowser_4)

        self.textBrowser_9 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_9.setObjectName(u"textBrowser_9")

        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.textBrowser_9)

        self.textBrowser_10 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_10.setObjectName(u"datetime_entry")


        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.textBrowser_10)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
        # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionMain.setText(QCoreApplication.translate("MainWindow", u"Main", None))
        # self.actionLV01.setText(QCoreApplication.translate("MainWindow", u"LV01_01", None))
        # self.actionLV01_02.setText(QCoreApplication.translate("MainWindow", u"LV01_02", None))
        # self.actionView_Records.setText(QCoreApplication.translate("MainWindow", u"View Records", None))
        # self.actionCompany_Details.setText(QCoreApplication.translate("MainWindow", u"Company Details", None))
        # self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))
        #self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))
        # self.actionUser_Authentication.setText(QCoreApplication.translate("MainWindow", u"User Authentication", None))
        # self.actionCamera_Setting.setText(QCoreApplication.translate("MainWindow", u"Camera Setting", None))
        # self.actionLV02_01.setText(QCoreApplication.translate("MainWindow", u"LV02_01", None))
        # self.actionLV02_02.setText(QCoreApplication.translate("MainWindow", u"LV02_02", None))
        self.textBrowser_13.setHtml(QCoreApplication.translate("MainWindow",
                                                               u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                               "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                               "p, li { white-space: pre-wrap; }\n"
                                                               "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                               "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">DATE</p></body></html>",
                                                               None))
        self.textBrowser_12.setHtml(QCoreApplication.translate("MainWindow",
                                                               u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                               "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                               "p, li { white-space: pre-wrap; }\n"
                                                               "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                               "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">TIME</p></body></html>",
                                                               None))
        self.textBrowser_14.setHtml(QCoreApplication.translate("MainWindow",
                                                               u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                               "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                               "p, li { white-space: pre-wrap; }\n"
                                                               "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                               "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Count</p></body></html>",
                                                               None))

        #self.plainTextEdit.setPlainText("")
        self.plainTextEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Search by Name", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Search", None))

        __sortingEnabled = self.listWidget.isSortingEnabled()
        self.listWidget.setSortingEnabled(False)
        ___qlistwidgetitem = self.listWidget.item(0)
        ___qlistwidgetitem.setText(QCoreApplication.translate("MainWindow", u"ID:", None));
        ___qlistwidgetitem1 = self.listWidget.item(1)
        ___qlistwidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Name:", None));
        ___qlistwidgetitem2 = self.listWidget.item(2)
        ___qlistwidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Contact:", None));
        ___qlistwidgetitem3 = self.listWidget.item(3)
        ___qlistwidgetitem3.setText(QCoreApplication.translate("MainWindow", u"Time Entry:", None));
        self.listWidget.setSortingEnabled(__sortingEnabled)

        self.textBrowser_5.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">ID:</p></body></html>",
                                                              None))
        self.textBrowser_8.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">COMPANY</p></body></html>",
                                                              None))
        self.textBrowser.setHtml(QCoreApplication.translate("MainWindow",
                                                            u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                            "p, li { white-space: pre-wrap; }\n"
                                                            "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                            "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">NAME:</p></body></html>",
                                                            None))
        self.textBrowser_9.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">DATE/TIME:</p></body></html>",
                                                              None))

    # retranslateUi





