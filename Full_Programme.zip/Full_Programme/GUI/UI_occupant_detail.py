# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'occupants_detailRwViNv.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *



class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1201, 850)
        self.actionMain = QAction(MainWindow)
        self.actionMain.setObjectName(u"actionMain")
        # self.actionLV01 = QAction(MainWindow)
        # self.actionLV01.setObjectName(u"actionLV01")
        # self.actionLV01_02 = QAction(MainWindow)
        # self.actionLV01_02.setObjectName(u"actionLV01_02")
        # self.actionView_Records = QAction(MainWindow)
        # self.actionView_Records.setObjectName(u"actionView_Records")
        # self.actionCompany_Details = QAction(MainWindow)
        # self.actionCompany_Details.setObjectName(u"actionCompany_Details")
        # self.actionOccupants_Details = QAction(MainWindow)
        # self.actionOccupants_Details.setObjectName(u"actionOccupants_Details")
        # self.actionUser_Authentication = QAction(MainWindow)
        # self.actionUser_Authentication.setObjectName(u"actionUser_Authentication")
        # self.actionCamera_Setting = QAction(MainWindow)
        # self.actionCamera_Setting.setObjectName(u"actionCamera_Setting")
        # self.actionLV02_01 = QAction(MainWindow)
        # self.actionLV02_01.setObjectName(u"actionLV02_01")
        # self.actionLV02_02 = QAction(MainWindow)
        # self.actionLV02_02.setObjectName(u"actionLV02_02")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.tableWidget = QTableWidget(self.centralwidget)
        if (self.tableWidget.columnCount() < 4):
            self.tableWidget.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(0, 400, 1201, 391))
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(100, 110, 241, 261))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.textBrowser = QTextBrowser(self.centralwidget)
        self.textBrowser.setObjectName(u"textBrowser")
        self.textBrowser.setGeometry(QRect(0, 0, 241, 41))
        self.horizontalLayoutWidget = QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(370, 20, 421, 31))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.textBrowser_2 = QTextBrowser(self.horizontalLayoutWidget)
        self.textBrowser_2.setObjectName(u"textBrowser_2")
        self.textBrowser_2.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.horizontalLayout.addWidget(self.textBrowser_2)

        self.input_NID = QTextEdit(self.horizontalLayoutWidget)
        self.input_NID.setObjectName(u"input_NID")

        self.horizontalLayout.addWidget(self.input_NID)

        self.btn_srch = QPushButton(self.centralwidget)
        self.btn_srch.setObjectName(u"btn_srch")
        self.btn_srch.setGeometry(QRect(800, 27, 93, 21))
        self.formLayoutWidget = QWidget(self.centralwidget)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(390, 110, 591, 261))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.textBrowser_3 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_3.setObjectName(u"textBrowser_3")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.textBrowser_3)

        self.id_in = QTextEdit(self.formLayoutWidget)
        self.id_in.setObjectName(u"id_in")
        self.id_in.setReadOnly(True)

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.id_in)

        self.textBrowser_4 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_4.setObjectName(u"textBrowser_4")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.textBrowser_4)

        self.name_in = QTextEdit(self.formLayoutWidget)
        self.name_in.setObjectName(u"name_in")
        self.name_in.setReadOnly(True)

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.name_in)

        self.textBrowser_5 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_5.setObjectName(u"textBrowser_5")

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.textBrowser_5)

        self.textBrowser_6 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_6.setObjectName(u"textBrowser_6")

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.textBrowser_6)

        self.textBrowser_7 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_7.setObjectName(u"textBrowser_7")

        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.textBrowser_7)

        self.gender_in = QTextEdit(self.formLayoutWidget)
        self.gender_in.setObjectName(u"gender_in")
        self.gender_in.setReadOnly(True)

        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.gender_in)

        self.comp_in = QTextEdit(self.formLayoutWidget)
        self.comp_in.setObjectName(u"comp_in")
        self.comp_in.setReadOnly(True)

        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.comp_in)

        self.pos_in = QTextEdit(self.formLayoutWidget)
        self.pos_in.setObjectName(u"pos_in")
        self.pos_in.setReadOnly(True)

        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.pos_in)

        self.datereg_in = QTextEdit(self.formLayoutWidget)
        self.datereg_in.setObjectName(u"datereg_in")
        self.datereg_in.setReadOnly(True)

        self.formLayout.setWidget(5, QFormLayout.FieldRole, self.datereg_in)

        self.textBrowser_8 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_8.setObjectName(u"textBrowser_8")

        self.formLayout.setWidget(5, QFormLayout.LabelRole, self.textBrowser_8)

        self.btn_flt = QPushButton(self.centralwidget)
        self.btn_flt.setObjectName(u"btn_flt")
        self.btn_flt.setGeometry(QRect(800, 67, 93, 21))
        self.horizontalLayoutWidget_2 = QWidget(self.centralwidget)
        self.horizontalLayoutWidget_2.setObjectName(u"horizontalLayoutWidget_2")
        self.horizontalLayoutWidget_2.setGeometry(QRect(370, 60, 421, 31))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.textBrowser_9 = QTextBrowser(self.horizontalLayoutWidget_2)
        self.textBrowser_9.setObjectName(u"textBrowser_9")
        self.textBrowser_9.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.horizontalLayout_2.addWidget(self.textBrowser_9)

        self.input_NID_2 = QTextEdit(self.horizontalLayoutWidget_2)
        self.input_NID_2.setObjectName(u"input_NID_2")

        self.horizontalLayout_2.addWidget(self.input_NID_2)

        self.blacklist = QCheckBox(self.centralwidget)
        self.blacklist.setObjectName(u"blacklist")
        self.blacklist.setGeometry(QRect(1025, 335, 160, 50))

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        # self.menuBar = QMenuBar(MainWindow)
        # self.menuBar.setObjectName(u"menuBar")
        # self.menuBar.setGeometry(QRect(0, 0, 1201, 26))
        # self.menuENTRANCE = QMenu(self.menuBar)
        # self.menuENTRANCE.setObjectName(u"menuENTRANCE")
        # self.menuLV01 = QMenu(self.menuENTRANCE)
        # self.menuLV01.setObjectName(u"menuLV01")
        # self.menuLV02 = QMenu(self.menuENTRANCE)
        # self.menuLV02.setObjectName(u"menuLV02")
        # self.menuview = QMenu(self.menuBar)
        # self.menuview.setObjectName(u"menuview")
        # self.menuUSER = QMenu(self.menuBar)
        # self.menuUSER.setObjectName(u"menuUSER")
        # self.menuSETTING = QMenu(self.menuBar)
        # self.menuSETTING.setObjectName(u"menuSETTING")
        # self.menuOccupants = QMenu(self.menuBar)
        # self.menuOccupants.setObjectName(u"menuOccupants")
        # MainWindow.setMenuBar(self.menuBar)
        #
        # self.menuBar.addAction(self.menuENTRANCE.menuAction())
        # self.menuBar.addAction(self.menuview.menuAction())
        # self.menuBar.addAction(self.menuUSER.menuAction())
        # self.menuBar.addAction(self.menuOccupants.menuAction())
        # self.menuBar.addAction(self.menuSETTING.menuAction())
        # self.menuENTRANCE.addAction(self.menuLV01.menuAction())
        # self.menuENTRANCE.addAction(self.menuLV02.menuAction())
        # self.menuLV01.addAction(self.actionLV01)
        # self.menuLV01.addAction(self.actionLV01_02)
        # self.menuLV02.addAction(self.actionLV02_01)
        # self.menuLV02.addAction(self.actionLV02_02)
        # self.menuview.addAction(self.actionView_Records)
        # self.menuUSER.addAction(self.actionUser_Authentication)
        # self.menuSETTING.addAction(self.actionCamera_Setting)
        # self.menuOccupants.addAction(self.actionCompany_Details)
        # self.menuOccupants.addAction(self.actionOccupants_Details)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        # self.actionMain.setText(QCoreApplication.translate("MainWindow", u"Main", None))
        # self.actionLV01.setText(QCoreApplication.translate("MainWindow", u"LV01_01", None))
        # self.actionLV01_02.setText(QCoreApplication.translate("MainWindow", u"LV01_02", None))
        # self.actionView_Records.setText(QCoreApplication.translate("MainWindow", u"View Records", None))
        # self.actionCompany_Details.setText(QCoreApplication.translate("MainWindow", u"Company Details", None))
        # self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))
        # self.actionUser_Authentication.setText(QCoreApplication.translate("MainWindow", u"User Authentication", None))
        # self.actionCamera_Setting.setText(QCoreApplication.translate("MainWindow", u"Camera Setting", None))
        # self.actionLV02_01.setText(QCoreApplication.translate("MainWindow", u"LV02_01", None))
        # self.actionLV02_02.setText(QCoreApplication.translate("MainWindow", u"LV02_02", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"Date", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Time", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Zone", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"Status", None));
        self.textBrowser.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600;\">Occupant's Detail</span></p></body></html>", None))
        self.textBrowser_2.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Name / ID</span></p></body></html>", None))
        self.btn_srch.setText(QCoreApplication.translate("MainWindow", u"Search", None))
        self.textBrowser_3.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"right\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">ID :</span></p></body></html>", None))
        self.textBrowser_4.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"right\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">NAME :</span></p></body></html>", None))
        self.textBrowser_5.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"right\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Gender :</span></p></body></html>", None))
        self.textBrowser_6.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"right\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">COMPANY :</span></p></body></html>", None))
        self.textBrowser_7.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"right\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">POSITION :</span></p></body></html>", None))
        self.textBrowser_8.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"right\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">DATE REGISTERED :</span></p></body></html>", None))
        self.btn_flt.setText(QCoreApplication.translate("MainWindow", u"Filter", None))
        self.textBrowser_9.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Filter</span></p></body></html>", None))
        self.blacklist.setText(QCoreApplication.translate("MainWindow", u"Blacklist", None))
        # self.menuENTRANCE.setTitle(QCoreApplication.translate("MainWindow", u"ENTRANCE", None))
        # self.menuLV01.setTitle(QCoreApplication.translate("MainWindow", u"LV01", None))
        # self.menuLV02.setTitle(QCoreApplication.translate("MainWindow", u"LV02", None))
        # self.menuview.setTitle(QCoreApplication.translate("MainWindow", u"VIEW", None))
        # self.menuUSER.setTitle(QCoreApplication.translate("MainWindow", u"USER", None))
        # self.menuSETTING.setTitle(QCoreApplication.translate("MainWindow", u"SETTING", None))
        # self.menuOccupants.setTitle(QCoreApplication.translate("MainWindow", u"Occupants", None))
    # retranslateUi




