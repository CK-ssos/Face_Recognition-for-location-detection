import sys
from PySide2.QtWidgets import QApplication, QMainWindow, QLabel
from PySide2.QtGui import QPixmap, QImage
from UI_occupant_record import Ui_MainWindow
import sqlite3


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Create an instance of the UI
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # Connect to the database
        self.con = sqlite3.connect("Occupants.db")

        # Load the first occupant's photo from the database and display it in the frame
        self.load_second_occupant_photo()

    def load_first_occupant_photo(self):
        cursor = self.con.execute("SELECT Photo FROM Occupants LIMIT 1")
        row = cursor.fetchone()

        if row is not None:
            photo_data = row[0]
            image = QImage.fromData(photo_data)
            pixmap = QPixmap.fromImage(image)

            # Create a QLabel widget to display the photo
            photo_label = QLabel(self.ui.frame)
            photo_label.setPixmap(pixmap)
            photo_label.setScaledContents(True)
            photo_label.setGeometry(170, 0, 320, 330)

    def load_second_occupant_photo(self):
        x = 4
        cursor = self.con.execute("SELECT Photo FROM Occupants LIMIT 1 OFFSET " + str(x))
        row = cursor.fetchone()

        if row is not None:
            photo_data = row[0]
            print(photo_data)
            image = QImage.fromData(photo_data)
            pixmap = QPixmap.fromImage(image)

            # Create a QLabel widget to display the photo
            photo_label = QLabel(self.ui.frame)
            photo_label.setPixmap(pixmap)
            photo_label.setScaledContents(True)
            photo_label.setGeometry(170, 0, 320, 330)


if __name__ == "__main__":
    # Create the application
    app = QApplication(sys.argv)

    # Create and show the main window
    window = MainWindow()
    window.show()

    # Execute the application's event loop
    sys.exit(app.exec_())



