# import sqlite3
#
# # Connect to the database
# conn = sqlite3.connect('Occupants.db')
# cursor = conn.cursor()
#
# # Execute the DELETE statement to clear the data in the table
# cursor.execute('DELETE FROM Detected_Occ')
#
# # Commit the changes and close the connection
# conn.commit()
# conn.close()
#
# print("Data cleared from the table.")


# import sqlite3
#
# def retrieve_occupants(con):
#     cursor = con.execute("SELECT * FROM Detected_Occ")
#     rows = cursor.fetchall()
#     for row in rows:
#         record_id = row[0]
#         oid = row[1]
#         name = row[2]
#         contact = row[3]
#         datetime = row[4]
#         photo = row[5]
#         zone = row[6]
#         status = row[7]
#         print(f"RecordID: {record_id}")
#         print(f"OID: {oid}")
#         print(f"NAME: {name}")
#         print(f"Contact: {contact}")
#         print(f"DATETIME: {datetime}")
#         #print(f"Photo: {photo}")
#         print(f"Zone: {zone}")
#         print(f"Status: {status}")
#         print("DONE")
#
# # Connect to the database
# conn = sqlite3.connect('Occupants.db')
# cursor = conn.cursor()
#
# # Execute the SELECT statement to fetch all rows from the table
# cursor.execute('SELECT * FROM Detected_Occ')
# rows = cursor.fetchall()
#
# # Print the column headers
# column_names = [description[0] for description in cursor.description]
# print(column_names)
#
# # Print the data rows
# for row in rows:
#     print(row)
#
# print("DONE")
# #Close the connection
# conn.close()




from PySide2.QtSql import QSqlDatabase, QSqlQuery


def create_detected_occupants_table(self):
    # Connect to the database
    db = QSqlDatabase.addDatabase("QSQLITE")
    db.setDatabaseName("Occupants.db")
    if not db.open():
        print("Failed to connect to the database.")
        return

    # Execute a query to create the "Detected_Occ" table
    query = QSqlQuery()
    query.prepare(
        '''CREATE TABLE IF NOT EXISTS Detected_Occ(
                 RecordID INTEGER PRIMARY KEY AUTOINCREMENT,
                 OID INTEGER,
                 Name VARCHAR(255),
                 Contact CHAR(11),
                 DetectedDT DATETIME,
                 Photo BLOB,
                 Zone CHAR(10),
                 Status CHAR(5)
                 )
                 ''')

    if not query.exec_():
        print("Failed to create the Detected_Occ table.")
        db.close()
        return

    # Close the database connection
    db.close()

def delete_detected_occ_table():
    # Connect to the database
    db = QSqlDatabase.addDatabase("QSQLITE")
    db.setDatabaseName("Occupants.db")
    if not db.open():
        print("Failed to connect to the database.")
        return

    # Execute a query to delete the 'detected_occ' table
    query = QSqlQuery()
    if not query.exec_("DROP TABLE IF EXISTS detected_occ"):
        print("Failed to delete the 'detected_occ' table:", query.lastError().text())

    # Close the database connection
    db.close()

def drop_occ_status_table():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()

        # Drop the 'occ_status' table
        if query.exec_("DROP TABLE IF EXISTS occ_status"):
            print("'occ_status' table dropped successfully.")
        else:
            print("Failed to drop 'occ_status' table.")

        db.close()

    except Exception as e:
        print("Error dropping table:", e)

def drop_detected_trans_table():
    try:
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Create a QSqlQuery object
        query = QSqlQuery()

        # Execute a query to drop the 'Detected_Trans' table
        if query.exec_("DROP TABLE IF EXISTS Detected_Trans"):
            print("Table 'Detected_Trans' dropped successfully.")
        else:
            print("Failed to drop table 'Detected_Trans'.")

        # Close the database connection
        db.close()

    except Exception as e:
        print("Error dropping table:", e)


def retrieve_det_available_table():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        if not query.exec_("SELECT * FROM Det_Available"):
            print("Failed to retrieve data from the Det_Available table.")
            db.close()
            return

        print("\nDet_Available Table:")
        while query.next():
            trans_id = query.value(0)
            oid = query.value(1)
            detected_dt = query.value(2)
            zone = query.value(3)
            status = query.value(4)

            print(f"Trans_ID: {trans_id}, OID: {oid}, DetectedDT: {detected_dt}, Zone: {zone}, Status: {status}")

        db.close()

    except Exception as e:
        print("Error retrieving data from the Det_Available table:", e)

def clone_create_occstatus_table():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()

        query.exec_(
            '''CREATE TABLE IF NOT EXISTS occ_status AS
            SELECT OccupantsID, Name, DateAccessed AS LastDeteced FROM Occupants'''
        )

        print("Table 'occ_status' cloned successfully.")

        db.close()

    except Exception as e:
        print("Error cloning table:", e)

# def clone_table():
#     try:
#         db = QSqlDatabase.addDatabase("QSQLITE")
#         db.setDatabaseName("Occupants.db")
#         if not db.open():
#             print("Failed to connect to the database.")
#             return
#
#         query = QSqlQuery()
#
#         query.exec_(
#             '''CREATE TABLE IF NOT EXISTS occ_status AS
#             SELECT OccupantsID AS OID, Name, Last_Detected AS Date_Accessed, Status
#             FROM Occupants'''
#         )
#
#         print("Table 'occ_status' cloned successfully.")
#
#         db.close()
#
#     except Exception as e:
#         print("Error cloning table:", e)

def retrieve_cloned_table():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        if query.exec_("SELECT * FROM occ_status"):
            print("Data from 'occ_status' table:")

            while query.next():
                occ_id = query.value(0)
                name = query.value(1)
                date_accessed = query.value(2)
                status = query.value(3)

                print(f"Occupant ID: {occ_id}")
                print(f"Name: {name}")
                print(f"Last Detected: {date_accessed}")
                #print(f"Photo: {photo}")
                print(f"Status: {status}")

                print("-" * 50)
        else:
            print("Failed to retrieve data from 'occ_status' table.")

        db.close()

    except Exception as e:
        print("Error retrieving data:", e)

def modify_cloned_table():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()

        # Step 1: Create a backup of the 'occ_status' table
        if query.exec_("CREATE TABLE IF NOT EXISTS occ_status_backup AS SELECT * FROM occ_status"):
            print("Backup of 'occ_status' table created successfully.")
        else:
            print("Failed to create backup table.")

        # Step 2: Drop the original 'occ_status' table
        if query.exec_("DROP TABLE IF EXISTS occ_status"):
            print("'occ_status' table dropped successfully.")
        else:
            print("Failed to drop 'occ_status' table.")

        # Step 3: Recreate the 'occ_status' table with the desired columns
        if query.exec_("""
            CREATE TABLE IF NOT EXISTS occ_status (
                RecordID INTEGER PRIMARY KEY AUTOINCREMENT,
                Name VARCHAR(255),
                last_detected DATETIME,
                Status CHAR(5)
            )
        """):
            print("'occ_status' table recreated successfully.")
        else:
            print("Failed to create new 'occ_status' table.")

        # Step 4: Insert data from the backup table into the new 'occ_status' table
        if query.exec_("INSERT INTO occ_status (Name, last_detected, Status) SELECT Name, DateAccessed, Status FROM occ_status_backup"):
            print("Data inserted into new 'occ_status' table.")
        else:
            print("Failed to insert data into new 'occ_status' table.")

        # Step 5: Drop the backup table
        if query.exec_("DROP TABLE IF EXISTS occ_status_backup"):
            print("Backup table dropped.")
        else:
            print("Failed to drop backup table.")

        db.close()

    except Exception as e:
        print("Error modifying table:", e)

def delete_record_by_occ_id(occ_id):
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        query.prepare("DELETE FROM occ_status WHERE OccupantsID = ?")
        query.addBindValue(occ_id)

        if query.exec_():
            print(f"Deleted record with Occupant ID: {occ_id}")
        else:
            print(f"Failed to delete record with Occupant ID: {occ_id}")

        db.close()

    except Exception as e:
        print("Error deleting record:", e)

def add_status_column():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        if query.exec_("ALTER TABLE occ_status ADD COLUMN Zone CHAR(10)"):
            print("Added 'Status' column to 'occ_status' table.")
        else:
            print("Failed to add 'Zone' column to 'occ_status' table.")

        db.close()

    except Exception as e:
        print("Error adding column:", e)

def show_all_tables():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        if query.exec_("SELECT name FROM sqlite_master WHERE type='table'"):
            print("List of tables in the database:")

            while query.next():
                table_name = query.value(0)
                print(table_name)

        else:
            print("Failed to retrieve table names from the database:", query.lastError().text())

        db.close()

    except Exception as e:
        print("Error:", e)

def show_table_header(table_name):
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        if query.exec_(f"PRAGMA table_info({table_name})"):
            print(f"Column headers for table '{table_name}':")

            while query.next():
                column_name = query.value(1)
                print(column_name)

        else:
            print(f"Failed to retrieve column headers for table '{table_name}':", query.lastError().text())

        db.close()

    except Exception as e:
        print("Error:", e)

def create_detected_trans_table():
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")

        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to create the "Detected_Occ" table
        query = QSqlQuery()
        query.prepare(
            '''CREATE TABLE IF NOT EXISTS Detected_Trans(
                     TransID INTEGER PRIMARY KEY AUTOINCREMENT,
                     OID INTEGER,
                     Name VARCHAR(255),
                     LastDetectedDT DATETIME,
                     Zone CHAR(10),
                     Status CHAR(5)
                     )
                     ''')

        if not query.exec_():
            print("Failed to create the Detected_Trans table.")
            db.close()
            return

        # Close the database connection
        db.close()

def retrieve_detected_trans_table():
    try:
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        query = QSqlQuery()
        if query.exec_("SELECT * FROM Detected_Trans"):
            print("Data from 'Detected_Trans' table:")

            while query.next():
                trans_id = query.value(0)
                oid = query.value(1)
                name = query.value(2)
                last_detected = query.value(3)
                zone = query.value(4)
                status = query.value(5)

                print(f"Trans ID: {trans_id}")
                print(f"OID: {oid}")
                print(f"Name: {name}")
                print(f"Last Detected: {last_detected}")
                print(f"Zone: {zone}")
                print(f"Status: {status}")

                print("-" * 50)
        else:
            print("Failed to retrieve data from 'Detected_Trans' table.")

        db.close()

    except Exception as e:
        print("Error retrieving data:", e)

def create_blacklist_table():
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")

        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to create the "Detected_Occ" table
        query = QSqlQuery()
        query.prepare(
            '''CREATE TABLE IF NOT EXISTS Blacklist(
                     BKID INTEGER PRIMARY KEY AUTOINCREMENT,
                     OID INTEGER,
                     Name VARCHAR(255),
                     BlacklistedDT DATETIME
                     )
                     ''')

        if not query.exec_():
            print("Failed to create the Blacklist table.")
            db.close()
            return

        # Close the database connection
        db.close()

def retrieve_blacklist_data():
    # Connect to the database
    db = QSqlDatabase.addDatabase("QSQLITE")
    db.setDatabaseName("Occupants.db")

    if not db.open():
        print("Failed to connect to the database.")
        return None

    blacklist_data = []

    query = QSqlQuery()
    query.prepare("SELECT BKID, OID, Name, BlacklistedDT FROM Blacklist")

    if query.exec_():
        while query.next():
            bk_id = query.value(0)
            oid = query.value(1)
            name = query.value(2)
            blacklist_dt = query.value(3)
            blacklist_data.append((bk_id, oid, name, blacklist_dt))
            for entry in blacklist_data:
                bk_id, oid, name, blacklist_dt = entry
                print(f"BKID: {bk_id}, OID: {oid}, Name: {name}, BlacklistedDT: {blacklist_dt}")

    else:
        print("Failed to retrieve data from the Blacklist table.")

    db.close()

def update_headers():
    db = QSqlDatabase.addDatabase("QSQLITE")
    db.setDatabaseName("Occupants.db")
    if not db.open():
        print("Failed to connect to the database.")
        return

    query = QSqlQuery()
    query.exec_("PRAGMA table_info(occ_status)")

    headers = []
    while query.next():
        headers.append(query.value(1))

    if headers[1] == "Status":
        query.exec_("ALTER TABLE occ_status RENAME COLUMN Status TO Name")
    if headers[3] != "Zone":
        query.exec_("ALTER TABLE occ_status RENAME COLUMN Zone TO Status")

    # Close the database connection
    db.close()

def view_detected_occ_table():
        try:
            # Connect to the database
            conn = QSqlDatabase.addDatabase("QSQLITE")
            conn.setDatabaseName("Occupants.db")
            if not conn.open():
                print("Failed to connect to the database.")
                return

            # Execute a SELECT query to retrieve all records from Detected_Occ table
            query = QSqlQuery("SELECT * FROM Detected_Occ")

            print("Detected_Occ Table Contents:")
            print("===========================")
            print("RecordID | OID | Name | Contact | DetectedDT | Zone | Status")
            print("-" * 60)

            while query.next():
                record_id = query.value(0)
                oid = query.value(1)
                name = query.value(2)
                contact = query.value(3)
                detected_dt = query.value(4)
                zone = query.value(6)
                status = query.value(7)
                print(f"{record_id:^9} | {oid:^4} | {name:<15} | {contact:^11} | {detected_dt} | {zone:^7} | {status:^6}")

            # Close the database connection
            conn.close()

        except Exception as e:
            print("Error viewing detected_occ table:", e)


def retrieve_table_columns(table_name, database_name):
    try:
        # Create a QSqlDatabase connection
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName(database_name)

        if not db.open():
            print("Failed to connect to the database.")
            return None

        query = QSqlQuery()
        query.exec_(f"PRAGMA table_info({table_name})")

        column_names = []

        while query.next():
            column_name = query.value(1)
            column_names.append(column_name)

        # Close the database connection
        db.close()

        return column_names

    except Exception as e:
        print("Error retrieving table columns:", e)
        return None



if __name__ == "__main__":
    #show_all_tables()
    show_table_header('occ_status')
    occ_id_to_delete = 30
    delete_record_by_occ_id(occ_id_to_delete)
    retrieve_cloned_table()

    #view_detected_occ_table()

    # table_name = 'occ_status'
    # database_name = 'Occupants.db'
    # columns = retrieve_table_columns(table_name, database_name)
    #
    # if columns:
    #     print("Column headers for table 'occ_status':")
    #     for column in columns:
    #         print(column)
    # else:
    #     print("Failed to retrieve column headers.")

