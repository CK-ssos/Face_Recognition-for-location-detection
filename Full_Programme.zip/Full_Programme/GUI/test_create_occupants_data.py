#connect database

import sqlite3


def create_occupants_table(con):
    con.execute('''CREATE TABLE IF NOT EXISTS Occupants(
                 OccupantsID INTEGER PRIMARY KEY AUTOINCREMENT,
                 Name VARCHAR(255),
                 Contact CHAR(11),
                 DOB DATE,
                 Gender VARCHAR(255),
                 Company VARCHAR(255),
                 Position VARCHAR(255),
                 DateAccessed DATETIME,
                 Photo BLOB
                 )
                 ''')

    #con.execute("DROP TABLE IF EXISTS Occupants")

    # con.execute('''CREATE TABLE IF NOT EXISTS Occupants(
    #              OccupantsID VARCHAR(10) PRIMARY KEY,
    #              Name VARCHAR(255),
    #              Contact CHAR(11),
    #              DOB DATE,
    #              Gender VARCHAR(255),
    #              Company VARCHAR(255),
    #              Position VARCHAR(255),
    #              DateAccessed DATETIME,
    #              Photo BLOB
    #              )
    #              ''')
    #
    # con.execute('''CREATE TRIGGER IF NOT EXISTS generate_occupants_id
    #              BEFORE INSERT ON Occupants
    #              FOR EACH ROW
    #              WHEN NEW.OccupantsID IS NULL
    #              BEGIN
    #                  UPDATE Occupants
    #                  SET OccupantsID = (
    #                      SELECT '22CV' || SUBSTR('00000' || (SELECT COALESCE(MAX(CAST(SUBSTR(OccupantsID, 6) AS INTEGER)), 0) + 1), -5)
    #                      FROM Occupants
    #                  )
    #                  WHERE rowid = NEW.rowid;
    #              END
    #              ''')



    # # Delete all rows from table
    # con.execute("DROP TABLE IF EXISTS Occupants")

def insert_occupant(con, name,contact, dob, gender,comp,pos,dateacc,photo_path):
    # Read the photo file as binary data
    with open(photo_path, 'rb') as file:
        photo_data = file.read()

    # Insert the occupant details into the database
    con.execute("INSERT INTO occupants (Name, Contact, DOB, Gender, Company, Position, DateAccessed, Photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                 (name,contact, dob, gender,comp,pos,dateacc,photo_data))
    con.commit()


def retrieve_occupants(con):
    cursor = con.execute("SELECT OccupantsID, Name, Contact, DOB, Gender, Company, Position, DateAccessed, Photo FROM Occupants")
    rows = cursor.fetchall()
    for row in rows:
        occupants_id = row[0]
        name = row[1]
        contact = row[2]
        dob = row[3]
        gender = row[4]
        company = row[5]
        position = row[6]
        date_accessed = row[7]
        photo = row[8]
        print(f"OccupantsID: {occupants_id}")
        print(f"Name: {name}")
        print(f"Contact: {contact}")
        print(f"DOB: {dob}")
        print(f"Gender: {gender}")
        print(f"Company: {company}")
        print(f"Position: {position}")
        print(f"Date Accessed: {date_accessed}")
        #print(f"Photo: {photo}")
        print()

#con = sqlite3.connect("Occupants.db")
#con.close()

con = sqlite3.connect("Occupants.db")
##retrieve_occupants(con)
# Create the occupants table if it doesn't exist
create_occupants_table(con)

# Insert occupant details with photo
name = 'Su Lee Seng'
contact = '60165789123'
dob = '1979-10-25'
gender = 'male'
comp = 'UTAR'
pos = 'Supervisor'
dateacc = '2023-06-02 10:00:15'
photo_path = 'images/Mr_su(vip).png'



insert_occupant(con, name, contact, dob, gender,comp,pos,dateacc,photo_path)
retrieve_occupants(con)

# Close the database connection
con.close()