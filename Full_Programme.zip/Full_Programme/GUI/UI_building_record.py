# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'building_recordcnMBKj.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from datetime import date


class Ui_BuildingrecordWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1425, 837)
        self.actionMain = QAction(MainWindow)
        self.actionMain.setObjectName(u"actionMain")
        # self.actionLV01 = QAction(MainWindow)
        # self.actionLV01.setObjectName(u"actionLV01")
        # self.actionLV01_02 = QAction(MainWindow)
        # self.actionLV01_02.setObjectName(u"actionLV01_02")
        # self.actionView_Records = QAction(MainWindow)
        # self.actionView_Records.setObjectName(u"actionView_Records")
        # self.actionCompany_Details = QAction(MainWindow)
        # self.actionCompany_Details.setObjectName(u"actionCompany_Details")
        # self.actionOccupants_Details = QAction(MainWindow)
        # self.actionOccupants_Details.setObjectName(u"actionOccupants_Details")
        # self.actionUser_Authentication = QAction(MainWindow)
        # self.actionUser_Authentication.setObjectName(u"actionUser_Authentication")
        # self.actionCamera_Setting = QAction(MainWindow)
        # self.actionCamera_Setting.setObjectName(u"actionCamera_Setting")
        # self.actionLV02_01 = QAction(MainWindow)
        # self.actionLV02_01.setObjectName(u"actionLV02_01")
        # self.actionLV02_02 = QAction(MainWindow)
        # self.actionLV02_02.setObjectName(u"actionLV02_02")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.textBrowser = QTextBrowser(self.centralwidget)
        self.textBrowser.setObjectName(u"textBrowser")
        self.textBrowser.setGeometry(QRect(0, 0, 261, 41))
        self.textBrowser.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.formLayoutWidget = QWidget(self.centralwidget)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(270, 90, 361, 211))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.textBrowser_2 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_2.setObjectName(u"textBrowser_2")

        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.textBrowser_2)

        self.textBrowser_3 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_3.setObjectName(u"textBrowser_3")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.textBrowser_3)

        self.textBrowser_4 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_4.setObjectName(u"textBrowser_4")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.textBrowser_4)

        self.textBrowser_5 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_5.setObjectName(u"textBrowser_5")

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.textBrowser_5)

        self.textBrowser_7 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_7.setObjectName(u"textBrowser_7")

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.textBrowser_7)

        self.combo_floor = QComboBox(self.formLayoutWidget)
        self.combo_floor.setObjectName(u"combo_floor")
        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.combo_floor)
        self.combo_floor.addItems([" ","Floor 1", "Floor 2", "Floor 3", "Floor 4", "Floor 5"])
        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.combo_floor)

        self.combo_entrance = QComboBox(self.formLayoutWidget)
        self.combo_entrance.setObjectName(u"combo_entrance")
        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.combo_entrance)
        self.combo_entrance.addItems([" ","Zone 1", "Zone 2", "Zone 3", "Zone 4"])
        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.combo_entrance)

        self.date_edit = QDateEdit(self.formLayoutWidget)
        self.date_edit.setObjectName(u"date_edit")
        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.date_edit)

        # Set properties for QDateEdit
        self.date_edit.setDisplayFormat("dd-MM-yyyy")
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(date.today())

        self.combo_status = QComboBox(self.formLayoutWidget)
        self.combo_status.setObjectName(u"combo_status")
        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.combo_status)
        self.combo_status.addItems([" ","IN", "OUT"])
        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.combo_status)

        self.combo_sort = QComboBox(self.formLayoutWidget)
        self.combo_sort.setObjectName(u"combo_sort")
        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.combo_sort)
        self.combo_sort.addItems([" ","Occupant ID", "Name", "Company", "Date Time", "Entrance", "Status"])
        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.combo_sort)

        self.btn_filter = QPushButton(self.centralwidget)
        self.btn_filter.setObjectName(u"btn_filter")
        self.btn_filter.setGeometry(QRect(540, 310, 93, 28))
        self.btn_summarize = QPushButton(self.centralwidget)
        self.btn_summarize.setObjectName(u"btn_summarize")
        self.btn_summarize.setGeometry(QRect(650, 310, 93, 28))
        self.btn_searchID = QPushButton(self.centralwidget)
        self.btn_searchID.setObjectName(u"btn_searchID")
        self.btn_searchID.setGeometry(QRect(760, 310, 93, 28))
        self.textBrowser_6 = QTextBrowser(self.centralwidget)
        self.textBrowser_6.setObjectName(u"textBrowser_6")
        self.textBrowser_6.setGeometry(QRect(230, 50, 81, 31))
        self.textBrowser_6.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textBrowser_6.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tableWidget = QTableWidget(self.centralwidget)
        if (self.tableWidget.columnCount() < 6):
            self.tableWidget.setColumnCount(6)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, __qtablewidgetitem5)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(10, 350, 1401, 431))
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        # self.menuBar = QMenuBar(MainWindow)
        # self.menuBar.setObjectName(u"menuBar")
        # self.menuBar.setGeometry(QRect(0, 0, 1425, 26))
        # self.menuENTRANCE = QMenu(self.menuBar)
        # self.menuENTRANCE.setObjectName(u"menuENTRANCE")
        # self.menuLV01 = QMenu(self.menuENTRANCE)
        # self.menuLV01.setObjectName(u"menuLV01")
        # self.menuLV02 = QMenu(self.menuENTRANCE)
        # self.menuLV02.setObjectName(u"menuLV02")
        # self.menuview = QMenu(self.menuBar)
        # self.menuview.setObjectName(u"menuview")
        # self.menuUSER = QMenu(self.menuBar)
        # self.menuUSER.setObjectName(u"menuUSER")
        # self.menuSETTING = QMenu(self.menuBar)
        # self.menuSETTING.setObjectName(u"menuSETTING")
        # self.menuOccupants = QMenu(self.menuBar)
        # self.menuOccupants.setObjectName(u"menuOccupants")
        # MainWindow.setMenuBar(self.menuBar)
        #
        # self.menuBar.addAction(self.menuENTRANCE.menuAction())
        # self.menuBar.addAction(self.menuview.menuAction())
        # self.menuBar.addAction(self.menuUSER.menuAction())
        # self.menuBar.addAction(self.menuOccupants.menuAction())
        # self.menuBar.addAction(self.menuSETTING.menuAction())
        # self.menuENTRANCE.addAction(self.menuLV01.menuAction())
        # self.menuENTRANCE.addAction(self.menuLV02.menuAction())
        # self.menuLV01.addAction(self.actionLV01)
        # self.menuLV01.addAction(self.actionLV01_02)
        # self.menuLV02.addAction(self.actionLV02_01)
        # self.menuLV02.addAction(self.actionLV02_02)
        # self.menuview.addAction(self.actionView_Records)
        # self.menuUSER.addAction(self.actionUser_Authentication)
        # self.menuSETTING.addAction(self.actionCamera_Setting)
        # self.menuOccupants.addAction(self.actionCompany_Details)
        # self.menuOccupants.addAction(self.actionOccupants_Details)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionMain.setText(QCoreApplication.translate("MainWindow", u"Main", None))
        # self.actionLV01.setText(QCoreApplication.translate("MainWindow", u"LV01_01", None))
        # self.actionLV01_02.setText(QCoreApplication.translate("MainWindow", u"LV01_02", None))
        # self.actionView_Records.setText(QCoreApplication.translate("MainWindow", u"View Records", None))
        # self.actionCompany_Details.setText(QCoreApplication.translate("MainWindow", u"Company Details", None))
        # self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))
        # self.actionUser_Authentication.setText(QCoreApplication.translate("MainWindow", u"User Authentication", None))
        # self.actionCamera_Setting.setText(QCoreApplication.translate("MainWindow", u"Camera Setting", None))
        # self.actionLV02_01.setText(QCoreApplication.translate("MainWindow", u"LV02_01", None))
        # self.actionLV02_02.setText(QCoreApplication.translate("MainWindow", u"LV02_02", None))
        self.textBrowser.setHtml(QCoreApplication.translate("MainWindow",
                                                            u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                            "p, li { white-space: pre-wrap; }\n"
                                                            "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                            "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt; font-weight:600;\">ABC Corporation</span></p></body></html>",
                                                            None))
        self.textBrowser_2.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">SORT BY</span></p></body></html>",
                                                              None))
        self.textBrowser_3.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">FLOOR</span></p></body></html>",
                                                              None))
        self.textBrowser_4.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">ENTRANCE</span></p></body></html>",
                                                              None))
        self.textBrowser_5.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">DATE</span></p></body></html>",
                                                              None))
        self.textBrowser_7.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">STATUS</span></p></body></html>",
                                                              None))
        self.btn_filter.setText(QCoreApplication.translate("MainWindow", u"Filter", None))
        self.btn_summarize.setText(QCoreApplication.translate("MainWindow", u"Summarize", None))
        self.btn_searchID.setText(QCoreApplication.translate("MainWindow", u"Search By ID", None))
        self.textBrowser_6.setHtml(QCoreApplication.translate("MainWindow",
                                                              u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                              "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                              "p, li { white-space: pre-wrap; }\n"
                                                              "</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
                                                              "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt;\">Filter</span></p></body></html>",
                                                              None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"Occupant ID", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Name", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Company", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"DateTime", None));
        ___qtablewidgetitem4 = self.tableWidget.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Entrance", None));
        ___qtablewidgetitem5 = self.tableWidget.horizontalHeaderItem(5)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"Status", None));
        # self.menuENTRANCE.setTitle(QCoreApplication.translate("MainWindow", u"ENTRANCE", None))
        # self.menuLV01.setTitle(QCoreApplication.translate("MainWindow", u"LV01", None))
        # self.menuLV02.setTitle(QCoreApplication.translate("MainWindow", u"LV02", None))
        # self.menuview.setTitle(QCoreApplication.translate("MainWindow", u"VIEW", None))
        # self.menuUSER.setTitle(QCoreApplication.translate("MainWindow", u"USER", None))
        # self.menuSETTING.setTitle(QCoreApplication.translate("MainWindow", u"SETTING", None))
        # self.menuOccupants.setTitle(QCoreApplication.translate("MainWindow", u"Occupants", None))
    # retranslateUi



