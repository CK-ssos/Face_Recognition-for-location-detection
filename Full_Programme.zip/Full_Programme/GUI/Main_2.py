import sys
from PySide2.QtWidgets import QApplication, QMainWindow, QTabWidget, QWidget, QLabel, QVBoxLayout, QHBoxLayout, \
    QMessageBox
from PySide2.QtGui import QColor
#from main_multicam import MultiCamWindow
#from main_cam1 import FVWindow
#from main_cam2 import FVWindow2
from test_main_occupants import MainOccupantsWindow
from main_building_record import BuildingRecord_Window
from main_occupant_detail import MainOccupants_DetailWindow
from UI_login import Ui_MainWindow
#from main_multicam import MultiCamWindow
from main_report import MainReport_Window



class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Create an instance of the Ui_MainWindow class
        self.ui = Ui_MainWindow()

        # Set up the user interface
        self.ui.setupUi(self)

        # Connect the login button to the login function
        self.ui.pushButton.clicked.connect(self.login)



        # Set the fixed size of the main window
        self.setFixedSize(self.size())

    def login(self):
        username = self.ui.textEdit.toPlainText()
        password = self.ui.textEdit_4.text()
        print(username)
        print(password)

        # Check if the username and password are valid
        if username == "aaa" and password == "aaa":
            QMessageBox.information(self, "Login Successful", "Welcome, admin!")
            self.open_fv_window()
        else:
            QMessageBox.warning(self, "Login Failed", "Invalid username or password. Please try again.")

    def open_fv_window(self):
        # Create the FVWindow instance
        self.myapp = MyApplication()

        # Hide the LoginWindow
        self.hide()

        # Show the FVWindow
        self.myapp.show()

    def closeEvent(self, event):
        # Close the FVWindow if it is open
        if hasattr(self, 'MyApplication'):
            self.myapp.close()

        event.accept()


class MyApplication(QMainWindow):
    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Tab Widget Example")
        self.setGeometry(100, 100, 800, 600)
        self.resize(1476, 871)
        self.setFixedSize(self.size())

        # Create a menu bar
        # menubar = self.menuBar()
        # file_menu = menubar.addMenu("File")
        # file_menu.addAction("Exit", self.close)

        # Create a tab widget
        tab_widget = QTabWidget()

        # Create tabs and add them to the tab widget
        #tab1 = QWidget()
        # tab2 = QWidget()
        # tab3 = QWidget()
        tab4 = QWidget()
        tab5 = QWidget()
        tab6 = QWidget()
        tab7 = QWidget()

        #tab_widget.addTab(tab1,"MultiCam")
        # tab_widget.addTab(tab2, "MainCam")
        # tab_widget.addTab(tab3, "ExitCam")
        tab_widget.addTab(tab4, "Occupant_Record")
        tab_widget.addTab(tab5, "Building_Record")
        tab_widget.addTab(tab6,"Occupant_Detail")
        tab_widget.addTab(tab7, "Analysis Report")

        # Create layout for each tab
        # layout1 = QVBoxLayout()
        # multicam_window = MultiCamWindow()
        # layout1.addWidget(multicam_window)
        # tab1.setLayout(layout1)

        # layout2 = QVBoxLayout()
        # fv_window = FVWindow()  # Create an instance of FVWindow
        # layout2.addWidget(fv_window)
        # tab2.setLayout(layout2)
        #
        # layout3 = QVBoxLayout()
        # fv_window2 = FVWindow2()
        # layout3.addWidget(fv_window2)
        # tab3.setLayout(layout3)

        layout4 = QVBoxLayout()
        occ_window = MainOccupantsWindow()
        layout4.addWidget(occ_window)
        tab4.setLayout(layout4)

        layout5 = QVBoxLayout()
        building_window = BuildingRecord_Window()
        layout5.addWidget(building_window)
        tab5.setLayout(layout5)

        # layout6 = QVBoxLayout()
        # occ_detail_window = MainOccupants_DetailWindow()
        # layout6.addWidget(occ_detail_window)
        # tab6.setLayout(layout6)
        layout6 = QHBoxLayout()  # Use QHBoxLayout to center-align content vertically
        occ_detail_window = MainOccupants_DetailWindow()
        layout6.addStretch()  # Add stretchable space before the content
        layout6.addWidget(occ_detail_window)  # Add the content (occupant detail) to the layout
        layout6.addStretch()  # Add stretchable space after the content
        tab6.setLayout(layout6)

        layout7 = QVBoxLayout()
        report_window = MainReport_Window()
        layout7.addWidget(report_window)
        tab7.setLayout(layout7)

        # Set the central widget to the tab widget
        self.setCentralWidget(tab_widget)

# def main():
#     app = QApplication(sys.argv)
#     my_app = MyApplication()
#     my_app.show()
#     sys.exit(app.exec_())

def main():
    # Create the QApplication instance
    app = QApplication(sys.argv)

    # Create the LoginWindow instance
    loginWindow = LoginWindow()

    # Show the login window
    loginWindow.show()

    # Start the application event loop
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
