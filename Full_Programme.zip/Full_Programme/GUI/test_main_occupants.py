import os
from io import BytesIO

import face_recognition

from UI_occupant_record import Ui_MainWindow
from PySide2.QtWidgets import QMainWindow, QApplication, QTextEdit, QTableWidgetItem, QSizePolicy, QHeaderView, QLabel, QMessageBox, QFileDialog, QLineEdit
from PySide2.QtGui import QFont, QPixmap, QImage
from PySide2.QtCore import Qt, QTimer, QDate, QByteArray, QBuffer, QIODevice, QRect
from PySide2.QtSql import QSqlDatabase, QSqlQuery



from datetime import datetime

class MainOccupantsWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MainOccupantsWindow, self).__init__()

        self.setupUi(self)

        self.setFixedSize(self.size())  # Set fixed window size
        self.setupReadOnlyFields()  # Set OID and ip_dateacc as read-only
        self.setupFieldStyle()  # Set style for the dateEdit field
        self.setFieldFont()  # Set font size for QTextEdit fields

        self.photo_label = QLabel(self.frame)
        self.photo_label.setScaledContents(True)
        self.photo_label.setGeometry(QRect(160, 0, 330, 320))

        self.create_occupants_table()


        #self.photo_label.setGeometry(QRect(0,0,330,320))

        # self.populateTable()  # Fetch records from database and populate table

        # Adjust table widget size to match scroll area
        #self.tableWidget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        #self.tableWidget.resize(self.scrollArea.width(), self.scrollArea.height())

        # Connect the QTimer timeout signal to the updateTable slot
        self.timer = QTimer()
        self.timer.timeout.connect(self.populateTable)
        self.timer.start(10000)  # Refresh every 10 seconds

        # Populate the table initially
        self.populateTable()
        self.tableWidget.cellClicked.connect(self.populateTextEdit)  # Connect cellClicked signal to populateTextEdit slot
        self.adjustTableSize()  # Adjust table widget size and column widths

        self.btn_refresh.clicked.connect(self.refreshWindow)
        self.btn_add.clicked.connect(self.addOccupant)
        self.btn_update.clicked.connect(self.updateOccupant)
        self.btn_dlt.clicked.connect(self.deleteOccupant)
        self.btn_refresh.clicked.connect(self.refreshWindow)
        self.upload_photo.clicked.connect(self.uploadButtonClicked)

        #self.btn_bck.clicked.connect(self.back_to_main())

        self.ip_photo = QLineEdit()  # Create the ip_photo attribute as a QLineEdit object

    def create_occupants_table(self):
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to insert the new occupant into the database
        query = QSqlQuery()
        query.prepare(
            '''CREATE TABLE IF NOT EXISTS Occupants(
                     OccupantsID INTEGER PRIMARY KEY AUTOINCREMENT,
                     Name VARCHAR(255),
                     Contact CHAR(11),
                     DOB DATE,
                     Gender VARCHAR(255),
                     Company VARCHAR(255),
                     Position VARCHAR(255),
                     DateAccessed DATETIME,
                     Photo BLOB
                     )
                     ''')

    def populateTable(self):

        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to fetch records
        query = QSqlQuery()
        query.prepare("SELECT * FROM Occupants")
        if not query.exec_():
            print("Failed to fetch records.")
            db.close()
            return

        # Clear the table widget
        ##self.tableWidget.clearContents()
        self.tableWidget.setRowCount(0)

        # Populate the table widget with the retrieved data
        row = 0
        # while query.next():
        #     self.tableWidget.insertRow(row)
        #     for column in range(query.record().count()):
        #         item = QTableWidgetItem(str(query.value(column)))
        #         item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)  # Set item flags
        #         item.setTextAlignment(Qt.AlignCenter)
        #         self.tableWidget.setItem(row, column, item)
        #     row += 1

        while query.next():
            self.tableWidget.insertRow(row)
            for column in range(query.record().count()):
                item = QTableWidgetItem(str(query.value(column)))
                if column == 0:  # Check if it's the OID column
                    item.setFlags(item.flags() | Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    item.setTextAlignment(Qt.AlignCenter)  # Set alignment to center
                    item.setData(Qt.UserRole, query.value(column))  # Store the OID value in UserRole
                else:
                    item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)  # Set item flags
                    item.setTextAlignment(Qt.AlignCenter)  # Set alignment to center

                self.tableWidget.setItem(row, column, item)

                table_item = self.tableWidget.item(row, column)
                if table_item is not None:
                    table_item.setFont(QFont("Arial", 12))  # Set font size to 12

            row += 1

        # Close the database connection
        db.close()

    def populateTextEdit(self, row, column):
        # Get the value of the selected row's OID column
        oid_value = self.tableWidget.item(row, 0).data(Qt.UserRole)

        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to fetch the record based on the OID value
        query = QSqlQuery()
        query.prepare("SELECT * FROM Occupants WHERE OccupantsID = :oid")
        query.bindValue(":oid", oid_value)
        if not query.exec_():
            print("Failed to fetch the record.")
            db.close()
            return

        # Fetch the record
        if query.next():
            # Populate the input fields with the retrieved data
            self.OID.setText(str(query.value(0)))
            self.ip_name.setText(query.value(1))
            self.ip_contact.setText(query.value(2))
            #self.dateEdit.setDate(query.value(3))
            self.ip_gender.setText(query.value(4))
            self.ip_comp.setText(query.value(5))
            self.ip_pos.setText(query.value(6))
            self.ip_dateacc.setText(query.value(7))

            # Retrieve the dob from the database
            dob = query.value(3)

            # Convert dob to QDate object
            dob_date = QDate.fromString(dob, "yyyy-MM-dd")

            # Format dob as "dd/mm/yyyy"
            dob_formatted = dob_date.toString("dd/MM/yyyy")

            # Set dob in the dateEdit widget
            self.dateEdit.setDate(dob_date)
            self.dateEdit.setDisplayFormat("dd/MM/yyyy")


            # # Retrieve the photo from the database and display it in the frame
            # photo_data = query.value(8)
            # image = QImage.fromData(photo_data)
            # pixmap = QPixmap.fromImage(image)
            #
            # # Clear the frame before adding the new QLabel
            # for child in self.ui.frame.children():
            #     if isinstance(child, QLabel):
            #         child.deleteLater()
            #
            # # Create a QLabel widget to display the photo
            # photo_label = QLabel(self.ui.frame)
            # photo_label.setPixmap(pixmap)
            # photo_label.setScaledContents(True)
            # photo_label.setGeometry(170, 0, 320, 330)

            # Retrieve the photo from the database and display it in the frame
            photo_data = query.value(8)
            #print(photo_data)
            image = QImage.fromData(photo_data)

            if not image.isNull():
                # Scale the image to fit the label size
                scaled_image = image.scaled(self.photo_label.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                            Qt.SmoothTransformation)
                # Create a QPixmap from the scaled image
                pixmap = QPixmap.fromImage(scaled_image)
                self.photo_label.setPixmap(pixmap)

            # # Create a QLabel widget to display the photo
            # photo_label = QLabel(self.frame)
            # photo_label.setPixmap(pixmap)
            # photo_label.setScaledContents(True)
            # photo_label.setGeometry(0, 0, self.frame.width(), self.frame.height())





        # Close the database connection
        db.close()

    def setupFieldStyle(self):
        style = """
                QDateEdit {
                    background-color: #FFFFFF;  /* Set background color */
                    border: 1px solid #CCCCCC;  /* Set border */
                    padding: 8.5px;  /* Set padding */
                    color: #000000;  /* Set text color */
                }
                """
        self.dateEdit.setStyleSheet(style)  # Apply the style to dateEdit

    def setupReadOnlyFields(self):
        self.OID.setEnabled(False)  # Set OID field as read-only
        self.ip_dateacc.setEnabled(False)  # Set ip_dateacc field as read-only
        #self.dateEdit.setEnabled(False)  # Set dateEdit field as read-only

    def setFieldFont(self):
        font = QFont()
        font.setPointSize(10)  # Set font size to 10

        textEdits = self.findChildren(QTextEdit)  # Find all QTextEdit widgets

        for textEdit in textEdits:
            textEdit.setFont(font)  # Apply the font to each QTextEdit

    def adjustTableSize(self):
        # Set the table widget size to match the scroll area
        self.tableWidget.setSizeAdjustPolicy(self.tableWidget.AdjustToContents)
        self.tableWidget.setSizePolicy(self.scrollAreaWidgetContents.sizePolicy())

        # Expand the size of columns to fit the widget
        header = self.tableWidget.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)

        header.setSectionResizeMode(0, QHeaderView.Fixed)
        header.resizeSection(0, 110)

        header.setSectionResizeMode(2, QHeaderView.Fixed)
        header.resizeSection(2, 140)

        header.setSectionResizeMode(3, QHeaderView.Fixed)
        header.resizeSection(3, 130)

        header.setSectionResizeMode(4, QHeaderView.Fixed)
        header.resizeSection(4, 120)

        header.setSectionResizeMode(5, QHeaderView.Fixed)
        header.resizeSection(5, 180)

        header.setSectionResizeMode(6, QHeaderView.Fixed)
        header.resizeSection(6, 160)

        header.setSectionResizeMode(7, QHeaderView.Fixed)
        header.resizeSection(7, 220)

    def refreshWindow(self):
        # Clear the input fields
        self.OID.clear()
        self.ip_name.clear()
        self.ip_contact.clear()
        self.dateEdit.clear()
        self.ip_gender.clear()
        self.ip_comp.clear()
        self.ip_pos.clear()
        self.ip_dateacc.clear()

        # Clear the photo frame
        self.clearPhotoFrame()

        # Refresh the table
        self.populateTable()

        # Adjust the table size
        self.adjustTableSize()

    def clearPhotoFrame(self):
        # Clear the photo label from the frame
        self.photo_label.clear()

    def addOccupant(self):
        name = self.ip_name.toPlainText()
        contact = self.ip_contact.toPlainText()
        gender = self.ip_gender.toPlainText()
        company = self.ip_comp.toPlainText()
        position = self.ip_pos.toPlainText()

        # Get the current date and time
        current_datetime = datetime.now()

        # Convert the current date and time to the desired format
        date_acc = current_datetime.strftime("%Y-%m-%d %H:%M:%S")

        # Convert the date of birth to the desired format
        dob = self.dateEdit.date().toString("yyyy-MM-dd")

        # Get the selected photo path
        photo_path = self.ip_photo.text()

        # Load the photo from the selected file
        image = QImage(photo_path)
        photo_data = QByteArray()
        buffer = QBuffer(photo_data)
        buffer.open(QIODevice.WriteOnly)
        image.save(buffer, "PNG")

        image_directory = "images"
        if not os.path.exists(image_directory):
            os.makedirs(image_directory)


        image_name = name
        image_filename = f"{image_name}.jpg"

        image_path = os.path.join(image_directory, image_filename)
        image.save(image_path)


        # buffer = QBuffer(photo_data)
        # buffer.open(QIODevice.WriteOnly)
        # image.save(buffer, "PNG")

        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to insert the new occupant into the database
        query = QSqlQuery()
        query.prepare(
            "INSERT INTO Occupants (Name, Contact, DOB, Gender, Company, Position, DateAccessed, Photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
        query.addBindValue(name)
        query.addBindValue(contact)
        query.addBindValue(dob)
        query.addBindValue(gender)
        query.addBindValue(company)
        query.addBindValue(position)
        query.addBindValue(date_acc)
        query.addBindValue(photo_data)

        if not query.exec_():
            error_message = "Failed to add occupant:\n" + query.lastError().text()
            QMessageBox.critical(self, "Error", error_message)
            db.close()
            return

        # Close the database connection
        db.close()

        # Clear the input fields after adding the occupant
        self.ip_name.clear()
        self.ip_contact.clear()
        self.ip_gender.clear()
        self.ip_comp.clear()
        self.ip_pos.clear()

        # Refresh the window to update the table and other components
        self.refreshWindow()

    def uploadButtonClicked(self):
        # Open a file dialog to select the photo file
        file_dialog = QFileDialog()
        file_dialog.setFileMode(QFileDialog.ExistingFile)
        file_dialog.setNameFilter("Images (*.png *.jpg *.jpeg *.bmp)")

        if file_dialog.exec_():
            selected_files = file_dialog.selectedFiles()
            if selected_files:
                photo_path = selected_files[0]

                # Load the photo from the selected file
                image = QImage(photo_path)

                photo_data = QByteArray()
                buffer = QBuffer(photo_data)
                buffer.open(QIODevice.WriteOnly)
                image.save(buffer, "PNG")

                if not image.isNull():
                    # Scale the image to fit the label size
                    scaled_image = image.scaled(self.photo_label.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                                Qt.SmoothTransformation)
                    # Create a QPixmap from the scaled image
                    pixmap = QPixmap.fromImage(scaled_image)
                    self.photo_label.setPixmap(pixmap)

                # Update the photo path in the text field
                self.ip_photo.setText(photo_path)

    def updateOccupant(self):
        # Get the values from the input fields
        oid = self.OID.toPlainText()
        name = self.ip_name.toPlainText()
        contact = self.ip_contact.toPlainText()
        gender = self.ip_gender.toPlainText()
        company = self.ip_comp.toPlainText()
        position = self.ip_pos.toPlainText()

        # Convert the date of birth to the desired format
        dob = self.dateEdit.date().toString("yyyy-MM-dd")


        # Get the selected photo path
        photo_path = self.ip_photo.text()

        # Load the photo from the selected file
        image = QImage(photo_path)
        photo_data = QByteArray()
        buffer = QBuffer(photo_data)
        buffer.open(QIODevice.WriteOnly)
        image.save(buffer, "PNG")

        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to update the existing occupant in the database
        query = QSqlQuery()
        query.prepare(
            "UPDATE Occupants SET Name = ?, Contact = ?, DOB = ?, Gender = ?, Company = ?, Position = ?, Photo = ? WHERE OccupantsID = ?")
        query.addBindValue(name)
        query.addBindValue(contact)
        query.addBindValue(dob)
        query.addBindValue(gender)
        query.addBindValue(company)
        query.addBindValue(position)
        query.addBindValue(photo_data)
        query.addBindValue(oid)

        if not query.exec_():
            error_message = "Failed to update occupant:\n" + query.lastError().text()
            QMessageBox.critical(self, "Error", error_message)
            db.close()
            return

        # Close the database connection
        db.close()

        # Refresh the window to update the table and other components
        self.refreshWindow()

    def deleteOccupant(self):
        # Get the value of the selected row's OID column
        current_row = self.tableWidget.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, "Delete Error", "Please select a record to delete.")
            return

        oid_value = self.tableWidget.item(current_row, 0).data(Qt.UserRole)

        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to delete the record based on the OID value
        query = QSqlQuery()
        query.prepare("DELETE FROM Occupants WHERE OccupantsID = :oid")
        query.bindValue(":oid", oid_value)

        if not query.exec_():
            error_message = "Failed to delete the occupant:\n" + query.lastError().text()
            QMessageBox.critical(self, "Error", error_message)
            db.close()
            return

        # Close the database connection
        db.close()

        # Refresh the window to update the table and other components
        self.refreshWindow()

        # Clear the input fields after a successful deletion
        self.refreshWindow()

if __name__ == "__main__":
    app = QApplication([])
    window = MainOccupantsWindow()
    window.show()
    app.exec_()
