from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        self.actionMain = QAction(MainWindow)
        self.actionMain.setObjectName(u"actionMain")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(220, 50, 360, 220))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)

        # Set the background color of the frame to grey
        #self.frame.setStyleSheet("background-color: gray;")

        # Create a QLabel for displaying the image
        self.label = QLabel(self.frame)
        self.label.setGeometry(QRect(0, 0, 361, 221))
        self.label.setScaledContents(True)  # Ensure the image is scaled to fit the label

        # Load the image using QPixmap
        image_path = "login2.png"
        pixmap = QPixmap(image_path)

        # Set the pixmap on the label
        self.label.setPixmap(pixmap)

        self.formLayoutWidget = QWidget(self.centralwidget)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(190, 300, 420, 120))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.textBrowser = QTextBrowser(self.formLayoutWidget)
        self.textBrowser.setObjectName(u"textBrowser")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.textBrowser)

        self.textEdit = QTextEdit(self.formLayoutWidget)
        self.textEdit.setObjectName(u"textEdit")

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.textEdit)


        self.textEdit_4 = QLineEdit(self.formLayoutWidget)
        self.textEdit_4.setObjectName(u"textEdit_4")
        self.textEdit_4.setEchoMode(QLineEdit.Password)  # Set echo mode to Password
        self.textEdit_4.setFixedHeight(40)
        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.textEdit)
        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.textEdit_4)

        self.textBrowser_4 = QTextBrowser(self.formLayoutWidget)
        self.textBrowser_4.setObjectName(u"textBrowser_4")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.textBrowser_4)

        self.pushButton = QPushButton(self.formLayoutWidget)
        self.pushButton.setObjectName(u"pushButton")

        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.pushButton)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 26))
        self.menuMain = QMenu(self.menubar)
        self.menuMain.setObjectName(u"menuMain")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.menubar.addAction(self.menuMain.menuAction())
        self.menuMain.addAction(self.actionMain)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        #self.actionMain.setText(QCoreApplication.translate("MainWindow", u"Main", None))
        self.textBrowser.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">ID</p></body></html>", None))
        self.textBrowser_4.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Password</p></body></html>", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Login", None))
        #self.menuMain.setTitle(QCoreApplication.translate("MainWindow", u"Main", None))
    # retranslateUi


