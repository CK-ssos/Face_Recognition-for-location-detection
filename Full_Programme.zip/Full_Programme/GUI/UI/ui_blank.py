# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'FVMFWnxq.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1442, 837)
        self.actionMain = QAction(MainWindow)
        self.actionMain.setObjectName(u"actionMain")
        self.actionLV01 = QAction(MainWindow)
        self.actionLV01.setObjectName(u"actionLV01")
        self.actionLV01_02 = QAction(MainWindow)
        self.actionLV01_02.setObjectName(u"actionLV01_02")
        self.actionView_Records = QAction(MainWindow)
        self.actionView_Records.setObjectName(u"actionView_Records")
        self.actionCompany_Details = QAction(MainWindow)
        self.actionCompany_Details.setObjectName(u"actionCompany_Details")
        self.actionOccupants_Details = QAction(MainWindow)
        self.actionOccupants_Details.setObjectName(u"actionOccupants_Details")
        self.actionUser_Authentication = QAction(MainWindow)
        self.actionUser_Authentication.setObjectName(u"actionUser_Authentication")
        self.actionCamera_Setting = QAction(MainWindow)
        self.actionCamera_Setting.setObjectName(u"actionCamera_Setting")
        self.actionLV02_01 = QAction(MainWindow)
        self.actionLV02_01.setObjectName(u"actionLV02_01")
        self.actionLV02_02 = QAction(MainWindow)
        self.actionLV02_02.setObjectName(u"actionLV02_02")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionMain.setText(QCoreApplication.translate("MainWindow", u"Main", None))
        self.actionLV01.setText(QCoreApplication.translate("MainWindow", u"LV01_01", None))
        self.actionLV01_02.setText(QCoreApplication.translate("MainWindow", u"LV01_02", None))
        self.actionView_Records.setText(QCoreApplication.translate("MainWindow", u"View Records", None))
        self.actionCompany_Details.setText(QCoreApplication.translate("MainWindow", u"Company Details", None))
        self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))
        self.actionUser_Authentication.setText(QCoreApplication.translate("MainWindow", u"User Authentication", None))
        self.actionCamera_Setting.setText(QCoreApplication.translate("MainWindow", u"Camera Setting", None))
        self.actionLV02_01.setText(QCoreApplication.translate("MainWindow", u"LV02_01", None))
        self.actionLV02_02.setText(QCoreApplication.translate("MainWindow", u"LV02_02", None))
    # retranslateUi

