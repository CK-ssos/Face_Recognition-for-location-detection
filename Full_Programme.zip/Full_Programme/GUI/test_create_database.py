def create_occupants_table(self):
    # Connect to the database
    db = QSqlDatabase.addDatabase("QSQLITE")
    db.setDatabaseName("Occupants.db")
    if not db.open():
        print("Failed to connect to the database.")
        return

    # Execute a query to insert the new occupant into the database
    query = QSqlQuery()
    query.prepare(
        '''CREATE TABLE IF NOT EXISTS Occupants(
                 OccupantsID INTEGER PRIMARY KEY AUTOINCREMENT,
                 Name VARCHAR(255),
                 Contact CHAR(11),
                 DOB DATE,
                 Gender VARCHAR(255),
                 Company VARCHAR(255),
                 Position VARCHAR(255),
                 DateAccessed DATETIME,
                 Photo BLOB
                 )
                 ''')


def create_detected_occupants_table(self):
        # Connect to the database
        db = QSqlDatabase.addDatabase("QSQLITE")
        db.setDatabaseName("Occupants.db")
        if not db.open():
            print("Failed to connect to the database.")
            return

        # Execute a query to create the "Detected_Occ" table
        query = QSqlQuery()
        query.prepare(
            '''CREATE TABLE IF NOT EXISTS Detected_Occ(
                     RecordID INTEGER PRIMARY KEY AUTOINCREMENT,
                     OID INTEGER,
                     Name VARCHAR(255),
                     Contact CHAR(11),
                     DetectedDT DATETIME,
                     Photo BLOB
                     )
                     ''')

        if not query.exec_():
            print("Failed to create the Detected_Occ table.")
            db.close()
            return

        # Close the database connection
        db.close()

from PySide2.QtSql import QSqlDatabase, QSqlQuery

def delete_detected_occ_table():
    # Connect to the database
    db = QSqlDatabase.addDatabase("QSQLITE")
    db.setDatabaseName("Occupants.db")
    if not db.open():
        print("Failed to connect to the database.")
        return

    # Execute a query to delete the 'detected_occ' table
    query = QSqlQuery()
    if not query.exec_("DROP TABLE IF EXISTS detected_occ"):
        print("Failed to delete the 'detected_occ' table:", query.lastError().text())

    # Close the database connection
    db.close()

if __name__ == "__main__":
    delete_detected_occ_table()






