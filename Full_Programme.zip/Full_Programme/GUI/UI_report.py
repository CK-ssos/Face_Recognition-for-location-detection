# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'reportnoXbhL.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class UI_ReportWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1464, 878)
        self.actionMain = QAction(MainWindow)
        self.actionMain.setObjectName(u"actionMain")
        self.actionLV01 = QAction(MainWindow)
        self.actionLV01.setObjectName(u"actionLV01")
        self.actionLV01_02 = QAction(MainWindow)
        self.actionLV01_02.setObjectName(u"actionLV01_02")
        self.actionView_Records = QAction(MainWindow)
        self.actionView_Records.setObjectName(u"actionView_Records")
        self.actionCompany_Details = QAction(MainWindow)
        self.actionCompany_Details.setObjectName(u"actionCompany_Details")
        self.actionOccupants_Details = QAction(MainWindow)
        self.actionOccupants_Details.setObjectName(u"actionOccupants_Details")
        self.actionUser_Authentication = QAction(MainWindow)
        self.actionUser_Authentication.setObjectName(u"actionUser_Authentication")
        self.actionCamera_Setting = QAction(MainWindow)
        self.actionCamera_Setting.setObjectName(u"actionCamera_Setting")
        self.actionLV02_01 = QAction(MainWindow)
        self.actionLV02_01.setObjectName(u"actionLV02_01")
        self.actionLV02_02 = QAction(MainWindow)
        self.actionLV02_02.setObjectName(u"actionLV02_02")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.horizontalLayoutWidget = QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(10, 40, 1451, 461))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.att_view = QGraphicsView(self.horizontalLayoutWidget)
        self.att_view.setObjectName(u"att_view")


        self.verticalLayout.addWidget(self.att_view)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.r_day = QRadioButton(self.horizontalLayoutWidget)
        self.r_day.setObjectName(u"r_day")

        self.horizontalLayout_2.addWidget(self.r_day)

        self.r_month = QRadioButton(self.horizontalLayoutWidget)
        self.r_month.setObjectName(u"r_month")

        self.horizontalLayout_2.addWidget(self.r_month)

        self.r_year = QRadioButton(self.horizontalLayoutWidget)
        self.r_year.setObjectName(u"r_year")

        self.horizontalLayout_2.addWidget(self.r_year)


        self.verticalLayout.addLayout(self.horizontalLayout_2)


        self.horizontalLayout.addLayout(self.verticalLayout)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.daytime_view = QGraphicsView(self.horizontalLayoutWidget)
        self.daytime_view.setObjectName(u"daytime_view")

        self.verticalLayout_2.addWidget(self.daytime_view)

        self.dateEdit = QDateEdit(self.horizontalLayoutWidget)
        self.dateEdit.setObjectName(u"dateEdit")

        self.verticalLayout_2.addWidget(self.dateEdit)


        self.horizontalLayout.addLayout(self.verticalLayout_2)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.textBrowser_2 = QTextBrowser(self.horizontalLayoutWidget)
        self.textBrowser_2.setObjectName(u"textBrowser_2")

        self.verticalLayout_4.addWidget(self.textBrowser_2)

        self.formselectdata = QFormLayout()
        self.formselectdata.setObjectName(u"formselectdata")
        self.selectDataLabel = QLabel(self.horizontalLayoutWidget)
        self.selectDataLabel.setObjectName(u"selectDataLabel")

        self.formselectdata.setWidget(0, QFormLayout.LabelRole, self.selectDataLabel)

        self.selectDataComboBox = QComboBox(self.horizontalLayoutWidget)
        self.selectDataComboBox.setObjectName(u"selectDataComboBox")
        self.selectDataComboBox.addItems([" ", "Building's Occupants", "Detected Occupants Record","Occupant Detail"])

        self.formselectdata.setWidget(0, QFormLayout.FieldRole, self.selectDataComboBox)

        self.verticalLayout_4.addLayout(self.formselectdata)

        self.formdate = QFormLayout()
        self.formdate.setObjectName(u"formdate")
        self.fromLabel = QLabel(self.horizontalLayoutWidget)
        self.fromLabel.setObjectName(u"fromLabel")

        self.formdate.setWidget(0, QFormLayout.LabelRole, self.fromLabel)

        self.fromDateEdit = QDateEdit(self.horizontalLayoutWidget)
        self.fromDateEdit.setObjectName(u"fromDateEdit")

        self.formdate.setWidget(0, QFormLayout.FieldRole, self.fromDateEdit)

        self.toLabel = QLabel(self.horizontalLayoutWidget)
        self.toLabel.setObjectName(u"toLabel")

        self.formdate.setWidget(1, QFormLayout.LabelRole, self.toLabel)

        self.toDateEdit = QDateEdit(self.horizontalLayoutWidget)
        self.toDateEdit.setObjectName(u"toDateEdit")

        self.formdate.setWidget(1, QFormLayout.FieldRole, self.toDateEdit)


        self.verticalLayout_4.addLayout(self.formdate)

        self.formocc = QFormLayout()
        self.formocc.setObjectName(u"formocc")
        self.nameComboBox = QComboBox(self.horizontalLayoutWidget)
        self.nameComboBox.setObjectName(u"nameComboBox")

        self.formocc.setWidget(0, QFormLayout.FieldRole, self.nameComboBox)

        self.nameLabel = QLabel(self.horizontalLayoutWidget)
        self.nameLabel.setObjectName(u"nameLabel")

        self.formocc.setWidget(0, QFormLayout.LabelRole, self.nameLabel)

        self.verticalLayout_4.addLayout(self.formocc)

        self.btn_export = QPushButton(self.horizontalLayoutWidget)
        self.btn_export.setObjectName(u"btn_export")

        self.verticalLayout_4.addWidget(self.btn_export)

        self.horizontalLayout.addLayout(self.verticalLayout_4)

        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")

        self.horizontalLayout.addLayout(self.verticalLayout_3)

        self.textBrowser = QTextBrowser(self.centralwidget)
        self.textBrowser.setObjectName(u"textBrowser")
        self.textBrowser.setGeometry(QRect(0, 0, 181, 31))
        self.textBrowser.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textBrowser.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.listWidget = QListWidget(self.centralwidget)
        self.listWidget.setObjectName(u"listWidget")
        self.listWidget.setGeometry(QRect(10, 510, 1451, 341))
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionMain.setText(QCoreApplication.translate("MainWindow", u"Main", None))
        self.actionLV01.setText(QCoreApplication.translate("MainWindow", u"LV01_01", None))
        self.actionLV01_02.setText(QCoreApplication.translate("MainWindow", u"LV01_02", None))
        self.actionView_Records.setText(QCoreApplication.translate("MainWindow", u"View Records", None))
        self.actionCompany_Details.setText(QCoreApplication.translate("MainWindow", u"Company Details", None))
        self.actionOccupants_Details.setText(QCoreApplication.translate("MainWindow", u"Occupants Details", None))
        self.actionUser_Authentication.setText(QCoreApplication.translate("MainWindow", u"User Authentication", None))
        self.actionCamera_Setting.setText(QCoreApplication.translate("MainWindow", u"Camera Setting", None))
        self.actionLV02_01.setText(QCoreApplication.translate("MainWindow", u"LV02_01", None))
        self.actionLV02_02.setText(QCoreApplication.translate("MainWindow", u"LV02_02", None))
        self.r_day.setText(QCoreApplication.translate("MainWindow", u"Day", None))
        self.r_month.setText(QCoreApplication.translate("MainWindow", u"Month", None))
        self.r_year.setText(QCoreApplication.translate("MainWindow", u"Year", None))
        self.textBrowser_2.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600;\">Export Data</span></p></body></html>", None))
        self.selectDataLabel.setText(QCoreApplication.translate("MainWindow", u"Select Data", None))
        self.fromLabel.setText(QCoreApplication.translate("MainWindow", u"From", None))
        self.toLabel.setText(QCoreApplication.translate("MainWindow", u"To", None))
        self.nameLabel.setText(QCoreApplication.translate("MainWindow", u"Name", None))
        self.btn_export.setText(QCoreApplication.translate("MainWindow", u"Export", None))
        self.textBrowser.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">Dashboard Report</span></p></body></html>", None))
    # retranslateUi

